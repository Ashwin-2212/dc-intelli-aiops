import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini AI Client
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'DC-Intelli AIOps Telemetry Platform',
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    version: '2.4.0',
  });
});

// Simulator Incident Trigger Endpoints
app.post('/api/simulator/incidents/cooling-failure', (req, res) => {
  res.json({
    success: true,
    scenario: 'cooling_failure',
    target: 'CRAC-02',
    impact: 'Elevated inlet temperature across Zone A (R-04, R-05), fan speed 100%, return temp 37.0°C',
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/simulator/incidents/power-spike', (req, res) => {
  res.json({
    success: true,
    scenario: 'power_spike',
    target: 'UPS-01 / Substation Feeder A',
    impact: 'Facility load surge to 990 kW, PUE elevated to 1.54, UPS-01 at 90% load capacity',
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/simulator/incidents/ups-degradation', (req, res) => {
  res.json({
    success: true,
    scenario: 'ups_degradation',
    target: 'UPS-03 (Zone C High-Density)',
    impact: 'Battery State of Health degraded to 38%, runtime reduced to 8 minutes, cell resistance 34.8mΩ',
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/simulator/incidents/server-failure', (req, res) => {
  res.json({
    success: true,
    scenario: 'server_failure',
    target: 'SRV-R-04-02',
    impact: 'CPU thermal throttle at 82.5°C, response latency 18.5ms, thread lock cascade',
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/simulator/incidents/reset', (req, res) => {
  res.json({
    success: true,
    scenario: 'normal',
    impact: 'All physical cooling loops, UPS batteries, and server workloads restored to nominal baselines',
    timestamp: new Date().toISOString(),
  });
});

// Telemetry & Infrastructure Metadata APIs
app.get('/api/sites', (req, res) => {
  res.json([
    {
      id: 'dc-va-01',
      name: 'Alpha Core DC-1 (Ashburn, VA)',
      tier: 'Tier IV',
      status: 'operational',
      powerCapacityKw: 1100,
      currentPowerKw: 842.5,
      pue: 1.40,
      racksCount: 24,
      serversCount: 168,
      overallHealth: 88,
    },
    {
      id: 'dc-fra-02',
      name: 'Echo Cloud DC-2 (Frankfurt)',
      tier: 'Tier III',
      status: 'operational',
      powerCapacityKw: 800,
      currentPowerKw: 560.0,
      pue: 1.36,
      racksCount: 18,
      serversCount: 124,
      overallHealth: 94,
    },
  ]);
});

// AIOps Gemini Copilot Endpoint
app.post('/api/gemini/copilot', async (req, res) => {
  try {
    const { prompt, history } = req.body;
    const telemetryContext = req.body.telemetryContext || req.body.context || {};
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGenAI();
    if (!ai) {
      // Intelligent fallback grounded in live telemetry context if API key is not yet set
      const replyText = `[AIOps Expert Rule Engine Response]
Regarding your query: "${prompt}"

Based on current live data center telemetry:
• Total Facility Power: ${telemetryContext?.totalPowerKw || telemetryContext?.powerKw || '842.5'} kW (PUE: ${telemetryContext?.pue || '1.40'})
• Active Hotspots: Rack R-04 / R-05 inlet temperatures are elevated (33.8°C), correlated with CRAC-02 airflow throttling.
• UPS Status: UPS-01 & UPS-02 nominal, UPS-03 battery string 2B degradation detected (64% Health, 18-day projected maintenance window).

Recommended Actions:
1. Dispatch technician to inspect CRAC-02 fan motor and actuator valve.
2. Balance virtual workloads across compute clusters to minimize localized hot-aisle recirculation.
3. Review capacity projections for upcoming quarter.

*(Configure GEMINI_API_KEY in AI Studio Settings for live Gemini 3.7 Flash neural reasoning)*`;

      return res.json({
        response: replyText,
        reply: replyText,
        source: 'local_expert_engine',
      });
    }

    const systemInstruction = `You are "DC-Intelli Copilot", a world-class Principal Data Center Infrastructure Architect and AIOps Reliability Engineer.
You analyze real-time data center telemetry (PUE, CRAC cooling efficiency, UPS battery impedance, 42U rack thermal profiles, CPU/RAM/Disk IOPS, network latency, and capacity forecasts).
Provide precise, technical, highly actionable engineering answers.
Format answers cleanly with bullet points, exact metric numbers, root cause explanations, and prioritized next steps.
Never invent fake telemetry; use the provided context accurately.`;

    const fullPrompt = `Data Center Live Telemetry Context:
${JSON.stringify(telemetryContext || {}, null, 2)}

User Question: ${prompt}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: fullPrompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    const outputText = response.text || 'Analysis completed.';

    res.json({
      response: outputText,
      reply: outputText,
      source: 'gemini-3.7-flash',
    });
  } catch (error: any) {
    console.error('Error generating Gemini response:', error);
    res.status(500).json({
      error: 'Failed to process AI Copilot query',
      details: error.message,
    });
  }
});

// Automated AI Work Order Generator Endpoint
app.post('/api/gemini/generate-work-order', async (req, res) => {
  try {
    const { incidentOrAnomaly } = req.body;
    const ai = getGenAI();

    const fallbackWorkOrder = {
      workOrderId: `WO-${Date.now().toString().slice(-5)}`,
      title: `Emergency Diagnostic: ${incidentOrAnomaly?.metric || 'Thermal Spiking'} on ${incidentOrAnomaly?.deviceName || 'Asset'}`,
      assignedTeam: 'Critical Facility & Thermal Management Team',
      priority: incidentOrAnomaly?.severity === 'critical' ? 'critical' : 'high',
      targetAsset: incidentOrAnomaly?.deviceId || 'Zone A Equipment',
      estimatedHours: 2.5,
      costEstimate: 450,
      instructions: `1. Isolate asset and verify physical airflow dampers.\n2. Measure static pressure across cold-aisle containment door.\n3. Execute thermal camera scan on power distribution whip.\n4. Log post-resolution telemetry.`,
    };

    if (!ai) {
      return res.json(fallbackWorkOrder);
    }

    const prompt = `Generate a formal Data Center Maintenance Work Order in JSON format for this anomaly:
${JSON.stringify(incidentOrAnomaly, null, 2)}

Output strictly valid JSON with keys: workOrderId, title, assignedTeam, priority (low|medium|high|critical), targetAsset, estimatedHours (number), costEstimate (number), instructions (numbered string).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (err: any) {
    console.error('Work order generation error:', err);
    res.json({
      workOrderId: `WO-${Date.now().toString().slice(-5)}`,
      title: `Preventive Inspection: ${req.body?.incidentOrAnomaly?.deviceName || 'Infrastructure Asset'}`,
      assignedTeam: 'Electrical & Mechanical Engineering',
      priority: 'high',
      targetAsset: req.body?.incidentOrAnomaly?.deviceId || 'DC-1',
      estimatedHours: 3.0,
      costEstimate: 380,
      instructions: 'Perform physical inspection, check motor bearings, test battery string resistance, and verify firmware logs.',
    });
  }
});

// Setup Vite development middleware or static production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DC-Intelli Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
