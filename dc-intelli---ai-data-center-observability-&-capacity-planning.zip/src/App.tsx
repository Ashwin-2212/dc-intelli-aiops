import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { SuperAdminControlView } from './components/SuperAdminControlView';
import { ManagerDashboardView } from './components/ManagerDashboardView';
import { EngineerDashboardView } from './components/EngineerDashboardView';
import { OperatorDashboardView } from './components/OperatorDashboardView';
import { OverviewDashboard } from './components/OverviewDashboard';
import { DigitalTwinView } from './components/DigitalTwinView';
import { RackManagementView } from './components/RackManagementView';
import { ServerMonitoringView } from './components/ServerMonitoringView';
import { CoolingIntelligenceView } from './components/CoolingIntelligenceView';
import { PowerEnergyView } from './components/PowerEnergyView';
import { UPSManagementView } from './components/UPSManagementView';
import { AiAnomaliesView } from './components/AiAnomaliesView';
import { PredictiveMaintenanceView } from './components/PredictiveMaintenanceView';
import { CapacityPlanningView } from './components/CapacityPlanningView';
import { WhatIfSandbox } from './components/WhatIfSandbox';
import { RootCauseAnalysisView } from './components/RootCauseAnalysisView';
import { IncidentWorkOrdersView } from './components/IncidentWorkOrdersView';
import { ReportsExportView } from './components/ReportsExportView';
import { SettingsAdminView } from './components/SettingsAdminView';
import { AiCopilotModal } from './components/AiCopilotModal';
import { TelemetryEngine } from './services/telemetrySimulator';
import { WorkOrder, UserRole } from './types';

export default function App() {
  const [activeView, setActiveView] = useState<string>('super-admin');
  const [currentRole, setCurrentRole] = useState<UserRole>('super_admin');
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [copilotInitialPrompt, setCopilotInitialPrompt] = useState<string>('');
  const [selectedRackForElevation, setSelectedRackForElevation] = useState<string>('R-04');
  const [workOrderNotification, setWorkOrderNotification] = useState<string | null>(null);

  // Subscribe to TelemetryEngine tick updates to keep entire app reactive
  const [, setTick] = useState(0);

  useEffect(() => {
    const engine = TelemetryEngine.getInstance();
    const unsubscribe = engine.subscribe(() => {
      setTick((t) => t + 1);
    });
    return () => unsubscribe();
  }, []);

  const handleOpenCopilot = (prompt?: string) => {
    if (prompt) setCopilotInitialPrompt(prompt);
    setIsCopilotOpen(true);
  };

  const handleSelectRack = (rackId: string) => {
    setSelectedRackForElevation(rackId);
    setActiveView('racks');
  };

  const handleSearchSelect = (query: string) => {
    const q = query.toLowerCase();
    if (q.includes('super') || q.includes('admin') || q.includes('kill') || q.includes('root')) {
      setActiveView('super-admin');
    } else if (q.includes('manager') || q.includes('budget') || q.includes('cockpit')) {
      setActiveView('manager-cockpit');
    } else if (q.includes('engineer') || q.includes('probe') || q.includes('diag')) {
      setActiveView('engineer-diag');
    } else if (q.includes('operator') || q.includes('noc')) {
      setActiveView('operator-noc');
    } else if (q.includes('rack') || q.includes('r-')) {
      setActiveView('racks');
    } else if (q.includes('server') || q.includes('cpu') || q.includes('blade')) {
      setActiveView('servers');
    } else if (q.includes('cool') || q.includes('crac') || q.includes('chiller') || q.includes('temp')) {
      setActiveView('cooling');
    } else if (q.includes('power') || q.includes('pue') || q.includes('kw') || q.includes('energy')) {
      setActiveView('power');
    } else if (q.includes('ups') || q.includes('battery')) {
      setActiveView('ups');
    } else if (q.includes('anom') || q.includes('alert')) {
      setActiveView('anomalies');
    } else if (q.includes('predict') || q.includes('fail') || q.includes('vibrat')) {
      setActiveView('predictive');
    } else if (q.includes('what') || q.includes('simul')) {
      setActiveView('what-if');
    } else {
      handleOpenCopilot(query);
    }
  };

  const handleGenerateWorkOrder = (sourceItem: any) => {
    const engine = TelemetryEngine.getInstance();
    const newOrder: WorkOrder = {
      id: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
      title: `Remediation for ${sourceItem.deviceName || sourceItem.targetAsset || sourceItem.deviceId || 'Asset'}`,
      targetAsset: sourceItem.deviceName || sourceItem.deviceId || 'CRAC-02',
      severity: sourceItem.severity || 'high',
      status: 'open',
      assignedTo: 'On-Call Technician (Auto-Dispatched)',
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      slaDueHours: sourceItem.severity === 'critical' ? 2 : 6,
      description: `Automated work order triggered by AIOps Engine for ${sourceItem.metric || sourceItem.component || 'Incident'}. Action required immediately.`,
    };

    engine.workOrders = [newOrder, ...engine.workOrders];
    setWorkOrderNotification(`Work Order ${newOrder.id} dispatched successfully!`);
    setTimeout(() => setWorkOrderNotification(null), 4000);
    setActiveView('incidents');
  };

  return (
    <div className="flex h-screen bg-[#070709] text-zinc-100 overflow-hidden font-sans select-none antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        currentRole={currentRole}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          currentRole={currentRole}
          onRoleChange={setCurrentRole}
          activeView={activeView}
          setActiveView={setActiveView}
          onOpenCopilot={() => handleOpenCopilot()}
          onOpenSimulationModal={() => setActiveView('what-if')}
          onSearchSelect={handleSearchSelect}
        />

        {/* Work Order Toast Notification */}
        {workOrderNotification && (
          <div className="bg-purple-600 text-white font-mono text-xs px-4 py-2 flex items-center justify-between shadow-lg z-30">
            <span>👑 {workOrderNotification}</span>
            <button
              onClick={() => setWorkOrderNotification(null)}
              className="text-white font-bold text-sm px-2"
            >
              ✕
            </button>
          </div>
        )}

        {/* Scrollable View Container */}
        <main className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-6">
            {activeView === 'super-admin' && (
              <SuperAdminControlView
                currentRole={currentRole}
                onRoleChange={setCurrentRole}
                setActiveView={setActiveView}
                onOpenCopilot={handleOpenCopilot}
              />
            )}

            {activeView === 'manager-cockpit' && (
              <ManagerDashboardView
                currentRole={currentRole}
                setActiveView={setActiveView}
                onOpenCopilot={handleOpenCopilot}
              />
            )}

            {activeView === 'engineer-diag' && (
              <EngineerDashboardView
                currentRole={currentRole}
                setActiveView={setActiveView}
                onOpenCopilot={handleOpenCopilot}
              />
            )}

            {activeView === 'operator-noc' && (
              <OperatorDashboardView
                currentRole={currentRole}
                setActiveView={setActiveView}
                onOpenCopilot={handleOpenCopilot}
              />
            )}

            {activeView === 'overview' && (
              <OverviewDashboard
                setActiveView={setActiveView}
                onOpenCopilot={handleOpenCopilot}
                onSelectRack={handleSelectRack}
              />
            )}

            {activeView === 'digital-twin' && (
              <DigitalTwinView onSelectRack={handleSelectRack} />
            )}

            {(activeView === 'racks' || activeView === 'assets') && (
              <RackManagementView selectedRackId={selectedRackForElevation} />
            )}

            {activeView === 'servers' && <ServerMonitoringView />}

            {activeView === 'cooling' && <CoolingIntelligenceView />}

            {(activeView === 'power' || activeView === 'energy-optimizer') && <PowerEnergyView />}

            {activeView === 'ups' && <UPSManagementView />}

            {activeView === 'anomalies' && (
              <AiAnomaliesView
                setActiveView={setActiveView}
                onGenerateWorkOrder={handleGenerateWorkOrder}
              />
            )}

            {activeView === 'predictive' && (
              <PredictiveMaintenanceView onGenerateWorkOrder={handleGenerateWorkOrder} />
            )}

            {activeView === 'capacity' && <CapacityPlanningView />}

            {activeView === 'what-if' && <WhatIfSandbox />}

            {activeView === 'root-cause' && (
              <RootCauseAnalysisView onGenerateWorkOrder={handleGenerateWorkOrder} />
            )}

            {activeView === 'incidents' && <IncidentWorkOrdersView />}

            {activeView === 'reports' && <ReportsExportView />}

            {(activeView === 'settings' || activeView === 'security') && <SettingsAdminView />}
          </div>
        </main>
      </div>

      {/* AI Operations Copilot Modal */}
      <AiCopilotModal
        isOpen={isCopilotOpen}
        onClose={() => {
          setIsCopilotOpen(false);
          setCopilotInitialPrompt('');
        }}
        initialPrompt={copilotInitialPrompt}
      />
    </div>
  );
}
