export type ServerStatus = 'healthy' | 'warning' | 'degraded' | 'critical' | 'offline';
export type AlertSeverity = 'info' | 'warning' | 'critical' | 'emergency';
export type IncidentStatus = 'open' | 'investigating' | 'assigned' | 'mitigated' | 'resolved' | 'closed';
export type UserRole = 'super_admin' | 'dc_admin' | 'engineer' | 'technician' | 'manager' | 'viewer';
export type SimulationScenario = 'normal' | 'high_load' | 'cooling_failure' | 'power_spike' | 'ups_degradation' | 'network_congestion' | 'server_failure';

export interface DeviceTelemetry {
  timestamp: number;
  cpuUsage: number; // 0-100%
  cpuTemp: number; // °C
  ramUsage: number; // 0-100%
  diskUsage: number; // 0-100%
  diskIOPS: number;
  networkInMbps: number;
  networkOutMbps: number;
  networkLatencyMs: number;
  powerDrawWatts: number;
  fanSpeedRpm: number;
  responseTimesMs: number;
  processCount: number;
  uptimeHours: number;
}

export interface ServerDevice {
  id: string;
  name: string;
  rackId: string;
  uPosition: number; // 1 to 42
  uHeight: number; // 1U, 2U, 4U
  model: string;
  manufacturer: string;
  serialNumber: string;
  ipAddress: string;
  macAddress: string;
  os: string;
  cpuCores: number;
  ramGb: number;
  storageTb: number;
  installDate: string;
  warrantyExpireDate: string;
  status: ServerStatus;
  healthScore: number; // 0-100
  telemetry: DeviceTelemetry;
  workloadType: 'Compute Node' | 'Database Cluster' | 'Storage Array' | 'AI Training Worker' | 'Edge Gateway' | 'Virtualization Host';
  anomalyScore?: number; // 0-1
  failureProbability?: number; // 0-100%
}

export interface RackUnit {
  id: string;
  name: string;
  datacenterId: string;
  zone: string;
  row: string;
  position: number;
  maxU: number; // 42U
  usedU: number;
  maxPowerKw: number; // e.g. 15 kW
  currentPowerKw: number;
  inletTempC: number;
  outletTempC: number;
  humidityPercent: number;
  status: ServerStatus;
  healthScore: number;
  airflowCfm: number;
  servers: ServerDevice[];
  pduStatus: 'normal' | 'warning' | 'overload';
  weightKg: number;
  maxWeightKg: number;
}

export interface CoolingUnit {
  id: string;
  name: string;
  datacenterId: string;
  zone: string;
  type: 'CRAC' | 'CRAH' | 'In-Row Chiller' | 'Liquid Immersion Loop';
  status: ServerStatus;
  supplyTempC: number;
  returnTempC: number;
  fanSpeedPercent: number;
  chilledWaterFlowLpm: number;
  powerDrawKw: number;
  copEfficiency: number; // Coefficient of Performance
  healthScore: number;
  failureProbability: number;
  maintenanceHoursUntilDue: number;
}

export interface UpsUnit {
  id: string;
  name: string;
  datacenterId: string;
  zone: string;
  capacityKva: number;
  currentLoadKw: number;
  loadPercent: number;
  batteryHealthPercent: number;
  batteryChargePercent: number;
  runtimeRemainingMinutes: number;
  inputVoltage: number;
  outputVoltage: number;
  temperatureC: number;
  batteryAgeYears: number;
  status: ServerStatus;
  healthScore: number;
  failureProbability: number;
}

export interface DataCenterFacility {
  id: string;
  name: string;
  location: string;
  tier: 'Tier III' | 'Tier IV';
  totalAreaSqFt: number;
  floorsCount: number;
  zonesCount: number;
  racksCount: number;
  serversCount: number;
  totalFacilityPowerKw: number;
  itEquipmentPowerKw: number;
  coolingPowerKw: number;
  pue: number;
  overallHealth: number;
  ambientTempC: number;
  ambientHumidityPercent: number;
  electricityRatePerKwh: number; // in USD or INR
  carbonIntensityGramsPerKwh: number;
}

export interface AnomalyRecord {
  id: string;
  timestamp: string;
  deviceId: string;
  deviceName: string;
  deviceType: 'server' | 'rack' | 'cooling' | 'ups' | 'network';
  metric: string;
  currentValue: number | string;
  expectedRange: string;
  anomalyScore: number; // 0 to 1
  severity: AlertSeverity;
  possibleCause: string;
  recommendedAction: string;
  status: 'active' | 'acknowledged' | 'resolved';
}

export interface PredictiveFailureRecord {
  id: string;
  deviceId: string;
  deviceName: string;
  deviceType: 'server' | 'cooling' | 'ups' | 'pdu';
  component: string;
  failureProbability: number; // 0-100%
  expectedWindowDays: string; // e.g. "12-18 days"
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  confidencePercent: number;
  factors: { factor: string; contributionPercent: number }[];
  recommendation: string;
  mtbfHours: number;
  mttrHours: number;
}

export interface CapacityForecastPoint {
  date: string;
  cpuCapacityPercent: number;
  ramCapacityPercent: number;
  storageCapacityPercent: number;
  powerDemandKw: number;
  powerCapacityLimitKw: number;
  rackOccupancyPercent: number;
  coolingCapacityPercent: number;
  projectedCost: number;
}

export interface WorkOrder {
  id: string;
  title: string;
  targetAsset: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  status: 'open' | 'in_progress' | 'resolved';
  assignedTo: string;
  createdAt: string;
  slaDueHours: number;
  description: string;
}

export interface IncidentRecord {
  id: string;
  title: string;
  severity: AlertSeverity;
  status: IncidentStatus;
  affectedAsset: string;
  rootCause: string;
  assignedEngineer: string;
  createdAt: string;
  resolvedAt?: string;
  resolutionTimeMinutes?: number;
  slaLimitMinutes: number;
  notes: string[];
}

export interface WorkOrderRecord {
  id: string;
  incidentId?: string;
  title: string;
  assignedTeam: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending_approval' | 'scheduled' | 'in_progress' | 'completed';
  scheduledDate: string;
  targetAsset: string;
  instructions: string;
  estimatedHours: number;
  costEstimate: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userName: string;
  userRole: UserRole;
  action: string;
  resource: string;
  ipAddress: string;
  details: string;
}

export interface EnergyOptimizationInsight {
  id: string;
  targetAsset: string;
  type: 'workload_consolidation' | 'thermal_setpoint' | 'underutilized_host' | 'airflow_blanking';
  description: string;
  potentialPowerSavingsKw: number;
  monthlyCostSavings: number;
  annualCo2ReductionKg: number;
  implementationEffort: 'Immediate' | 'Low' | 'Medium';
}

export interface WhatIfScenarioInput {
  additionalServers: number;
  avgCpuLoadPercent: number;
  perServerPowerWatts: number;
  electricityRate: number;
  coolingEfficiencyFactor: number;
  plannedWorkloadType: string;
}

export interface WhatIfScenarioResult {
  addedPowerKw: number;
  newTotalPowerKw: number;
  projectedPUE: number;
  pueDelta: number;
  addedCoolingKwRequired: number;
  requiredRacks: number;
  availableULeft: number;
  monthlyCostIncrease: number;
  capacityRiskLevel: 'Safe' | 'Moderate' | 'High' | 'Critical';
  bottlenecks: string[];
  recommendations: string[];
}
