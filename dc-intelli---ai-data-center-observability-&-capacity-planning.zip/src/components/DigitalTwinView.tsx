import React, { useState } from 'react';
import {
  Layers,
  Thermometer,
  Zap,
  Shield,
  Activity,
  Maximize2,
  Wind,
  Server,
  Info,
  ChevronRight,
  Flame,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';
import { RackUnit } from '../types';

interface DigitalTwinViewProps {
  onSelectRack: (rackId: string) => void;
}

export const DigitalTwinView: React.FC<DigitalTwinViewProps> = ({ onSelectRack }) => {
  const engine = TelemetryEngine.getInstance();
  const racks = engine.racks;
  const coolingUnits = engine.coolingUnits;
  const upsUnits = engine.upsUnits;

  const [displayMode, setDisplayMode] = useState<'thermal' | 'power' | 'health'>('thermal');
  const [selectedRackForModal, setSelectedRackForModal] = useState<RackUnit | null>(null);

  const getRackColor = (rack: RackUnit) => {
    if (displayMode === 'thermal') {
      if (rack.inletTempC > 30) return 'bg-rose-600 border-rose-400 text-white shadow-lg shadow-rose-900/50';
      if (rack.inletTempC > 25) return 'bg-amber-600 border-amber-400 text-white shadow-lg shadow-amber-900/40';
      return 'bg-emerald-700/80 border-emerald-500 text-white';
    }
    if (displayMode === 'power') {
      if (rack.currentPowerKw > 13) return 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-900/50';
      if (rack.currentPowerKw > 10) return 'bg-cyan-700 border-cyan-400 text-white';
      return 'bg-blue-800/80 border-blue-500 text-white';
    }
    // health mode
    if (rack.status === 'critical') return 'bg-rose-600 border-rose-400 text-white animate-pulse';
    if (rack.status === 'warning') return 'bg-amber-600 border-amber-400 text-white';
    return 'bg-emerald-700/80 border-emerald-500 text-white';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-tight font-mono">
              2.5D Data Center Digital Twin
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 font-mono">
              Alpha Core DC-1
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time physical spatial mapping of CRAC air handlers, cold/hot aisles, 42U rack rows, and UPS banks.
          </p>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-xl gap-1">
          <button
            onClick={() => setDisplayMode('thermal')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono transition-all flex items-center gap-1.5 ${
              displayMode === 'thermal'
                ? 'bg-gradient-to-r from-orange-600 to-rose-600 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Thermometer className="w-3.5 h-3.5" />
            <span>Thermal Heatmap</span>
          </button>
          <button
            onClick={() => setDisplayMode('power')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono transition-all flex items-center gap-1.5 ${
              displayMode === 'power'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Power Density</span>
          </button>
          <button
            onClick={() => setDisplayMode('health')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-mono transition-all flex items-center gap-1.5 ${
              displayMode === 'health'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Health & Risk</span>
          </button>
        </div>
      </div>

      {/* Main Digital Twin Interactive Floor Plan Canvas */}
      <div className="bg-[#08080a] border border-zinc-800 rounded-2xl p-6 relative overflow-hidden">
        {/* Floor Grid Blueprint Overlay */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, #ffffff 1px, transparent 0)',
            backgroundSize: '24px 24px',
          }}
        ></div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-zinc-800/80 pb-4">
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="text-zinc-400 uppercase font-semibold">Legend:</span>
            {displayMode === 'thermal' ? (
              <>
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-3 h-3 rounded-xs bg-emerald-600"></span> &lt; 24°C (Optimal Cold Aisle)
                </span>
                <span className="flex items-center gap-1.5 text-amber-400">
                  <span className="w-3 h-3 rounded-xs bg-amber-600"></span> 25°C–29°C (Warning)
                </span>
                <span className="flex items-center gap-1.5 text-rose-400">
                  <span className="w-3 h-3 rounded-xs bg-rose-600"></span> &gt; 30°C (Thermal Hotspot)
                </span>
              </>
            ) : displayMode === 'power' ? (
              <>
                <span className="flex items-center gap-1.5 text-blue-400">
                  <span className="w-3 h-3 rounded-xs bg-blue-700"></span> &lt; 10 kW (Standard)
                </span>
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <span className="w-3 h-3 rounded-xs bg-cyan-700"></span> 10–13 kW (High Density)
                </span>
                <span className="flex items-center gap-1.5 text-purple-400">
                  <span className="w-3 h-3 rounded-xs bg-purple-600"></span> &gt; 13 kW (Near PDU Limit)
                </span>
              </>
            ) : (
              <>
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-3 h-3 rounded-xs bg-emerald-600"></span> 100% Healthy
                </span>
                <span className="flex items-center gap-1.5 text-amber-400">
                  <span className="w-3 h-3 rounded-xs bg-amber-600"></span> Degraded
                </span>
                <span className="flex items-center gap-1.5 text-rose-400">
                  <span className="w-3 h-3 rounded-xs bg-rose-600"></span> Critical Fault
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-3 text-xs font-mono text-zinc-400">
            <span className="flex items-center gap-1">
              <Wind className="w-3.5 h-3.5 text-cyan-400 animate-pulse" /> Cold Aisle Airflow
            </span>
          </div>
        </div>

        {/* Isometric / Top-Down Floor Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Floor: Zone A, B, C */}
          <div className="lg:col-span-9 space-y-6">
            {/* Zone A: Row 1 & Row 2 */}
            <div className="p-4 bg-zinc-900/40 border border-zinc-800 rounded-xl relative">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold font-mono text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span> Zone A (High-Density Compute Rows)
                </span>
                <span className="text-[10px] text-zinc-500 font-mono">Cold Aisle Containment Active</span>
              </div>

              {/* CRAC Unit A Airflow */}
              <div className="mb-3 flex items-center justify-between bg-cyan-950/20 border border-cyan-500/20 px-3 py-1.5 rounded-lg text-xs font-mono text-cyan-300">
                <div className="flex items-center gap-2">
                  <Wind className="w-4 h-4 text-cyan-400" />
                  <span>CRAC-01 (Direct Expansion): Supply 18.5°C | 340 LPM</span>
                </div>
                <span className="text-[10px] bg-cyan-500/20 px-2 py-0.5 rounded text-cyan-200">68% Fan Speed</span>
              </div>

              {/* Row 1 Racks */}
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                {racks.slice(0, 6).map((rack) => (
                  <button
                    key={rack.id}
                    onClick={() => {
                      setSelectedRackForModal(rack);
                      onSelectRack(rack.id);
                    }}
                    className={`p-3 rounded-xl border text-center transition-all transform hover:-translate-y-1 hover:shadow-xl cursor-pointer ${getRackColor(
                      rack
                    )}`}
                  >
                    <div className="text-xs font-bold font-mono">{rack.id}</div>
                    <div className="text-[11px] font-mono mt-1 font-semibold">
                      {displayMode === 'thermal'
                        ? `${rack.inletTempC}°C`
                        : displayMode === 'power'
                        ? `${rack.currentPowerKw} kW`
                        : `${rack.healthScore}%`}
                    </div>
                    <div className="mt-1.5 text-[9px] uppercase tracking-tight opacity-80 truncate">
                      {rack.servers.length} Servers
                    </div>
                  </button>
                ))}
              </div>

              {/* Hot Aisle Exhaust Corridor */}
              <div className="my-3 py-1 bg-gradient-to-r from-rose-950/20 via-orange-950/30 to-rose-950/20 border-y border-orange-500/20 flex items-center justify-center text-[10px] font-mono text-orange-400/80 uppercase tracking-widest">
                ▲ Hot Aisle Return Plenum (Exhaust: ~33.5°C) ▲
              </div>

              {/* Row 2 Racks */}
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                {racks.slice(6, 12).map((rack) => (
                  <button
                    key={rack.id}
                    onClick={() => {
                      setSelectedRackForModal(rack);
                      onSelectRack(rack.id);
                    }}
                    className={`p-3 rounded-xl border text-center transition-all transform hover:-translate-y-1 hover:shadow-xl cursor-pointer ${getRackColor(
                      rack
                    )}`}
                  >
                    <div className="text-xs font-bold font-mono">{rack.id}</div>
                    <div className="text-[11px] font-mono mt-1 font-semibold">
                      {displayMode === 'thermal'
                        ? `${rack.inletTempC}°C`
                        : displayMode === 'power'
                        ? `${rack.currentPowerKw} kW`
                        : `${rack.healthScore}%`}
                    </div>
                    <div className="mt-1.5 text-[9px] uppercase tracking-tight opacity-80 truncate">
                      {rack.servers.length} Servers
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right 3 Cols: Facility Infrastructure Sub-systems */}
          <div className="lg:col-span-3 space-y-4">
            {/* Cooling Units Matrix */}
            <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-3">
              <h3 className="text-xs font-bold font-mono text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                <Wind className="w-4 h-4 text-cyan-400" />
                CRAC / CRAH Units
              </h3>
              {coolingUnits.map((crac) => (
                <div
                  key={crac.id}
                  className={`p-2.5 rounded-lg border text-xs font-mono ${
                    crac.status === 'critical'
                      ? 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                      : crac.status === 'warning'
                      ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>{crac.id}</span>
                    <span className="text-[10px] uppercase font-semibold">{crac.status}</span>
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-1">
                    Supply: {crac.supplyTempC}°C | COP: {crac.copEfficiency}
                  </div>
                  <div className="text-[10px] text-zinc-500">Power: {crac.powerDrawKw} kW</div>
                </div>
              ))}
            </div>

            {/* UPS Inverter Trains */}
            <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-3">
              <h3 className="text-xs font-bold font-mono text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                UPS Power Inverters
              </h3>
              {upsUnits.map((ups) => (
                <div
                  key={ups.id}
                  className={`p-2.5 rounded-lg border text-xs font-mono ${
                    ups.status === 'warning'
                      ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>{ups.id}</span>
                    <span>{ups.loadPercent}% Load</span>
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-1">
                    Battery SOH: {ups.batteryHealthPercent}% | {ups.runtimeRemainingMinutes}m reserve
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Selected Rack Quick Inspection Modal */}
      {selectedRackForModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0e0e11] border border-zinc-700 rounded-2xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div>
                <h3 className="text-lg font-bold font-mono text-white flex items-center gap-2">
                  <span>Rack {selectedRackForModal.id} Telemetry Profile</span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-sans uppercase font-bold ${
                      selectedRackForModal.status === 'critical'
                        ? 'bg-rose-500/20 text-rose-300'
                        : selectedRackForModal.status === 'warning'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-emerald-500/20 text-emerald-300'
                    }`}
                  >
                    {selectedRackForModal.status}
                  </span>
                </h3>
                <p className="text-xs text-zinc-400 font-mono">{selectedRackForModal.name}</p>
              </div>
              <button
                onClick={() => setSelectedRackForModal(null)}
                className="text-zinc-400 hover:text-white text-lg font-bold px-2"
              >
                ✕
              </button>
            </div>

            {/* Rack Specs Grid */}
            <div className="grid grid-cols-3 gap-3 font-mono text-xs">
              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-lg">
                <span className="text-zinc-500">Inlet / Outlet Temp</span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedRackForModal.inletTempC}°C / {selectedRackForModal.outletTempC}°C
                </div>
              </div>
              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-lg">
                <span className="text-zinc-500">Power Draw / Limit</span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedRackForModal.currentPowerKw} kW / {selectedRackForModal.maxPowerKw} kW
                </div>
              </div>
              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-lg">
                <span className="text-zinc-500">U-Space Occupancy</span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedRackForModal.usedU}U / {selectedRackForModal.maxU}U
                </div>
              </div>
            </div>

            {/* Installed Servers in this Rack */}
            <div className="space-y-2">
              <span className="text-xs font-mono uppercase tracking-wider text-zinc-400 font-semibold">
                Installed Compute Nodes ({selectedRackForModal.servers.length})
              </span>
              <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                {selectedRackForModal.servers.map((server) => (
                  <div
                    key={server.id}
                    className="p-2.5 bg-zinc-900/80 border border-zinc-800 rounded-lg flex items-center justify-between text-xs font-mono"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-orange-400 font-bold">U{server.uPosition}</span>
                      <span className="text-white font-medium">{server.name}</span>
                      <span className="text-[10px] text-zinc-500">({server.model})</span>
                    </div>
                    <div className="flex items-center gap-3 text-zinc-300">
                      <span>CPU: {server.telemetry.cpuUsage}%</span>
                      <span>Temp: {server.telemetry.cpuTemp}°C</span>
                      <span>{server.telemetry.powerDrawWatts}W</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <button
                onClick={() => setSelectedRackForModal(null)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
