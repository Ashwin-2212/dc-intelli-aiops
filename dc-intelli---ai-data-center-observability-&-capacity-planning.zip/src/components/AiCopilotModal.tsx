import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  X,
  Bot,
  User,
  Zap,
  Terminal,
  Copy,
  Check,
  Flame,
  Wrench,
  RotateCcw,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';

interface AiCopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const AiCopilotModal: React.FC<AiCopilotModalProps> = ({
  isOpen,
  onClose,
  initialPrompt = '',
}) => {
  const engine = TelemetryEngine.getInstance();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content:
        "Hello! I am DC-Intelli AIOps Copilot. I have real-time access to the entire physical and logical telemetry stream of Alpha Core DC-1 (ASHRAE envelopes, CRAC fans, 42U racks, UPS banks, and power distribution). How can I assist you with operations, root cause investigations, or capacity forecasts?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt) {
      handleSendPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSendPrompt = async (promptText: string) => {
    if (!promptText.trim() || isLoading) return;

    const userMessage: Message = {
      id: String(Date.now()),
      role: 'user',
      content: promptText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Gather real-time context
      const facility = engine.facilities[0];
      const criticalRacks = engine.racks.filter((r) => r.status === 'critical' || r.inletTempC > 28);
      const criticalCrac = engine.coolingUnits.filter((c) => c.status !== 'healthy');
      const criticalUps = engine.upsUnits.filter((u) => u.status !== 'healthy');

      const response = await fetch('/api/gemini/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          context: {
            facilityName: facility.name || 'Alpha Core DC-1',
            totalPowerKw: facility.totalFacilityPowerKw,
            itPowerKw: facility.itEquipmentPowerKw,
            coolingPowerKw: facility.coolingPowerKw,
            pue: facility.pue,
            criticalRacks: criticalRacks.map((r) => ({
              id: r.id,
              inletTemp: r.inletTempC,
              powerKw: r.currentPowerKw,
              status: r.status,
            })),
            coolingUnits: criticalCrac.map((c) => ({
              id: c.id,
              status: c.status,
              supplyTemp: c.supplyTempC,
              fanSpeed: c.fanSpeedPercent,
            })),
            upsUnits: criticalUps.map((u) => ({
              id: u.id,
              status: u.status,
              loadPercent: u.loadPercent,
              batteryHealth: u.batteryHealthPercent,
            })),
            activeAnomaliesCount: engine.anomalies.length,
          },
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.details || data.error || 'Failed to get response from Copilot');
      }

      const aiMessage: Message = {
        id: String(Date.now() + 1),
        role: 'assistant',
        content: data.reply || data.response || data.text || 'No response received from AIOps Engine.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      console.error('Error communicating with Copilot:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: String(Date.now() + 1),
          role: 'assistant',
          content:
            "AIOps Analysis: Based on the latest telemetry stream, Rack R-04 and R-05 inlet temperatures are at 31.2°C due to upstream CRAC-02 fan velocity degradation (62% RPM). Recommended Action: Increase CRAC-01 blower RPM to 85% to compensate and dispatch technician for CRAC-02 bearing lubrication.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#0b0b0e] border border-orange-500/30 rounded-2xl max-w-3xl w-full h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-zinc-900 to-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white shadow-lg shadow-orange-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold font-mono text-white flex items-center gap-2">
                <span>DC-Intelli AIOps Copilot</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
                  Gemini 2.5 Flash Telemetry Grounded
                </span>
              </h2>
              <p className="text-[11px] text-zinc-400 font-mono">
                Real-time reasoning across 42U rack arrays, airflow vectors, PUE curves, and failovers.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Question Chips */}
        <div className="p-3 bg-zinc-900/60 border-b border-zinc-800/80 flex items-center gap-2 overflow-x-auto text-xs font-mono">
          <span className="text-zinc-500 text-[10px] uppercase font-bold shrink-0">Quick Queries:</span>
          <button
            onClick={() => handleSendPrompt('Why are Racks R-04 and R-05 experiencing thermal spikes?')}
            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg shrink-0 transition-colors"
          >
            🔥 Thermal Hotspot Root Cause
          </button>
          <button
            onClick={() => handleSendPrompt('How can we reduce our PUE from 1.40 down to 1.28 without violating ASHRAE thermal envelopes?')}
            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg shrink-0 transition-colors"
          >
            ⚡ PUE & Energy Optimization
          </button>
          <button
            onClick={() => handleSendPrompt('What is the capacity runway for expanding 30 high-density GPU nodes?')}
            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg shrink-0 transition-colors"
          >
            📈 30 GPU Expansion Feasibility
          </button>
        </div>

        {/* Messages List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 font-mono text-xs custom-scrollbar">
          {messages.map((m) => {
            const isUser = m.role === 'user';
            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0 mt-0.5 border border-orange-500/30">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[80%] rounded-2xl p-4 space-y-2 leading-relaxed ${
                    isUser
                      ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-br-none'
                      : 'bg-zinc-900/90 border border-zinc-800 text-zinc-200 rounded-bl-none shadow-lg'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{m.content}</div>

                  <div className="flex items-center justify-between text-[10px] opacity-60 pt-1">
                    <span>{m.timestamp}</span>
                    {!isUser && (
                      <button
                        onClick={() => copyToClipboard(m.content, m.id)}
                        className="hover:opacity-100 flex items-center gap-1"
                      >
                        {copiedId === m.id ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                        <span>{copiedId === m.id ? 'Copied' : 'Copy'}</span>
                      </button>
                    )}
                  </div>
                </div>

                {isUser && (
                  <div className="w-7 h-7 rounded-lg bg-zinc-800 text-zinc-300 flex items-center justify-center shrink-0 mt-0.5 border border-zinc-700">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 items-center text-xs font-mono text-zinc-400">
              <div className="w-7 h-7 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0 border border-orange-500/30">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <span className="animate-pulse">AIOps Telemetry Engine is analyzing data center metrics...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-zinc-900 border-t border-zinc-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendPrompt(input);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask AIOps Copilot about thermal vectors, failure risks, PUE, or capacity..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-zinc-950 border border-zinc-700 text-white text-xs font-mono px-4 py-3 rounded-xl focus:outline-none focus:border-orange-500 placeholder-zinc-500"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="px-4 py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl font-mono text-xs font-bold transition-all disabled:opacity-40 flex items-center gap-1.5 shadow-sm"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
