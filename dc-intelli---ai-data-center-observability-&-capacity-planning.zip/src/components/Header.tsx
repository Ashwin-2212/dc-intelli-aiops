import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  Play,
  Pause,
  Search,
  Shield,
  Sliders,
  Sparkles,
  Zap,
  Crown,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';
import { UserRole, SimulationScenario } from '../types';

interface HeaderProps {
  currentRole?: UserRole;
  onRoleChange?: (role: UserRole) => void;
  onOpenCopilot: () => void;
  onOpenSimulationModal?: () => void;
  onSearchSelect?: (query: string) => void;
  activeView?: string;
  setActiveView?: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole = 'super_admin',
  onRoleChange,
  onOpenCopilot,
  onOpenSimulationModal,
  onSearchSelect,
  activeView = 'super-admin',
  setActiveView,
}) => {
  const engine = TelemetryEngine.getInstance();
  const facility = engine.facilities[0];
  const activeAnomaliesCount = engine.anomalies.filter((a) => a.status === 'active').length;
  const isRunning = engine.isRunning;
  const currentScenario = engine.currentScenario;

  const [searchQuery, setSearchQuery] = useState('');

  const getScenarioBadge = (sc: SimulationScenario) => {
    switch (sc) {
      case 'cooling_failure':
        return {
          label: 'CRAC-02 FAULT SIMULATION',
          color: 'bg-rose-500/15 text-rose-300 border-rose-500/40 animate-pulse',
        };
      case 'high_load':
        return {
          label: 'HIGH COMPUTE SURGE',
          color: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
        };
      case 'power_spike':
        return {
          label: 'POWER GRID TRANSIENT',
          color: 'bg-orange-500/15 text-orange-300 border-orange-500/40',
        };
      case 'ups_degradation':
        return {
          label: 'UPS BATTERY DEGRADATION',
          color: 'bg-purple-500/15 text-purple-300 border-purple-500/40',
        };
      default:
        return {
          label: 'NORMAL OPERATION',
          color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
        };
    }
  };

  const scenarioInfo = getScenarioBadge(currentScenario);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim() && onSearchSelect) {
      onSearchSelect(searchQuery.trim());
      setSearchQuery('');
    }
  };

  return (
    <header className="h-16 border-b border-zinc-800/80 bg-[#09090c]/95 backdrop-blur-md px-6 flex items-center justify-between z-20 sticky top-0 shrink-0">
      {/* Left: Quick Status Metrics */}
      <div className="flex items-center gap-6">
        {/* Stream Live Indicator */}
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            {isRunning && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            )}
            <span
              className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                isRunning ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
            ></span>
          </span>
          <span className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-300">
            {isRunning ? 'Telemetry Live' : 'Simulation Paused'}
          </span>
        </div>

        {/* DC Health */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-zinc-900/60 border border-zinc-800/60 rounded-lg">
          <span className="text-[10px] text-zinc-400 uppercase font-mono tracking-wider">Health</span>
          <span
            className={`text-xs font-bold font-mono ${
              facility.overallHealth > 80
                ? 'text-emerald-400'
                : facility.overallHealth > 65
                ? 'text-amber-400'
                : 'text-rose-400'
            }`}
          >
            {facility.overallHealth}%
          </span>
          <div className="flex gap-0.5">
            <div className={`w-1 h-3 rounded-xs ${facility.overallHealth > 50 ? 'bg-emerald-500' : 'bg-zinc-700'}`} />
            <div className={`w-1 h-3 rounded-xs ${facility.overallHealth > 75 ? 'bg-emerald-500' : 'bg-zinc-700'}`} />
            <div className={`w-1 h-3 rounded-xs ${facility.overallHealth > 85 ? 'bg-emerald-500' : 'bg-zinc-700'}`} />
          </div>
        </div>

        {/* PUE Quick */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1 bg-zinc-900/60 border border-zinc-800/60 rounded-lg">
          <span className="text-[10px] text-zinc-400 uppercase font-mono tracking-wider">PUE</span>
          <span className="text-xs font-bold font-mono text-zinc-100">{facility.pue.toFixed(2)}</span>
          <span
            className={`text-[9px] px-1 py-0.2 rounded font-mono font-bold uppercase ${
              facility.pue <= 1.4 ? 'text-emerald-400' : facility.pue <= 1.55 ? 'text-amber-400' : 'text-rose-400'
            }`}
          >
            {facility.pue <= 1.4 ? 'Optimal' : facility.pue <= 1.55 ? 'Nominal' : 'High'}
          </span>
        </div>

        {/* Live Fault Scenario Badge */}
        <button
          onClick={onOpenSimulationModal}
          className={`flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-mono font-medium transition-all hover:opacity-90 ${scenarioInfo.color}`}
          title="Click to change simulation fault scenario"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
          <span>{scenarioInfo.label}</span>
          <Sliders className="w-3 h-3 ml-0.5 opacity-70" />
        </button>
      </div>

      {/* Center: Search */}
      <div className="flex-1 max-w-md mx-6 hidden xl:block">
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search racks, cooling units, incidents, or ask copilot..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900/80 border border-zinc-800 rounded-lg pl-9 pr-4 py-1.5 text-xs text-zinc-200 placeholder-zinc-400 focus:outline-hidden focus:border-purple-500 transition-colors font-sans"
          />
        </form>
      </div>

      {/* Right: Controls & Profile */}
      <div className="flex items-center gap-3">
        {/* Simulation Pause/Play Toggle */}
        <button
          onClick={() => engine.toggleRunning()}
          className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors flex items-center gap-1.5 ${
            isRunning
              ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
              : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
          }`}
          title={isRunning ? 'Pause real-time telemetry stream' : 'Resume real-time telemetry stream'}
        >
          {isRunning ? <Pause className="w-3.5 h-3.5 text-emerald-400" /> : <Play className="w-3.5 h-3.5 text-amber-400" />}
          <span className="hidden sm:inline">{isRunning ? 'Pause Tick' : 'Resume Tick'}</span>
        </button>

        {/* AI Anomalies Pill Button */}
        <button
          onClick={() => setActiveView && setActiveView('anomalies')}
          className={`px-3 py-1.5 rounded-lg border text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1.5 transition-all ${
            activeAnomaliesCount > 0
              ? 'bg-rose-500/15 border-rose-500/40 text-rose-300 hover:bg-rose-500/25'
              : 'bg-zinc-900 border-zinc-800 text-zinc-400'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
          <span>{activeAnomaliesCount}</span>
          <span className="hidden sm:inline">Anomalies</span>
        </button>

        {/* Gemini AIOps Copilot Trigger */}
        <button
          onClick={onOpenCopilot}
          className="px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm hover:from-purple-500 hover:to-indigo-500 transition-all font-sans"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span className="hidden sm:inline">AIOps Copilot</span>
        </button>

        {/* Prioritized Role Selector (Super Admin Superiority) */}
        <div className="relative flex items-center gap-1.5 bg-zinc-950 border border-purple-800/70 rounded-lg px-2.5 py-1 text-xs shadow-sm">
          {currentRole === 'super_admin' ? (
            <Crown className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse shrink-0" />
          ) : (
            <Shield className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
          )}
          <label htmlFor="top-role-select" className="sr-only">
            Switch System Authority Role
          </label>
          <select
            id="top-role-select"
            value={currentRole}
            onChange={(e) => onRoleChange && onRoleChange(e.target.value as UserRole)}
            className="bg-transparent text-zinc-200 text-xs font-mono font-bold focus:outline-none cursor-pointer pr-1"
          >
            <option value="super_admin" className="bg-zinc-900 text-purple-300 font-bold">
              👑 Super Admin (Root)
            </option>
            <option value="dc_admin" className="bg-zinc-900 text-orange-300">
              🛡️ DC Site Admin
            </option>
            <option value="manager" className="bg-zinc-900 text-blue-300">
              📊 Operations Manager
            </option>
            <option value="engineer" className="bg-zinc-900 text-emerald-300">
              🔧 Lead Engineer
            </option>
            <option value="technician" className="bg-zinc-900 text-amber-300">
              ⚡ NOC Technician
            </option>
            <option value="viewer" className="bg-zinc-900 text-zinc-400">
              👁️ Read-Only Viewer
            </option>
          </select>
        </div>
      </div>
    </header>
  );
};
