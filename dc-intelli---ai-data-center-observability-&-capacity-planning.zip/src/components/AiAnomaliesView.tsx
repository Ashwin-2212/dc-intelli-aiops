import React, { useState } from 'react';
import {
  AlertTriangle,
  Flame,
  CheckCircle2,
  Cpu,
  Clock,
  Sparkles,
  GitBranch,
  Wrench,
  Search,
  Check,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';
import { AnomalyRecord } from '../types';

interface AiAnomaliesViewProps {
  setActiveView: (view: string) => void;
  onGenerateWorkOrder: (anomaly: AnomalyRecord) => void;
}

export const AiAnomaliesView: React.FC<AiAnomaliesViewProps> = ({
  setActiveView,
  onGenerateWorkOrder,
}) => {
  const engine = TelemetryEngine.getInstance();
  const [anomalies, setAnomalies] = useState<AnomalyRecord[]>(engine.anomalies);
  const [filterSeverity, setFilterSeverity] = useState<string>('all');

  const acknowledgeAnomaly = (id: string) => {
    setAnomalies(
      anomalies.map((a) => (a.id === id ? { ...a, status: 'acknowledged' } : a))
    );
  };

  const filtered = anomalies.filter((a) => {
    if (filterSeverity === 'all') return true;
    return a.severity === filterSeverity;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
              AI Anomaly Detection Radar
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-mono font-bold">
              Isolation Forest & Multivariate Z-Score
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Unsupervised machine learning model detecting non-linear telemetry deviations across CPU, thermal flux, power, and latency.
          </p>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2">
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="bg-zinc-900 border border-zinc-700 text-xs font-mono text-zinc-200 px-3 py-2 rounded-xl focus:outline-none"
          >
            <option value="all">All Severities ({anomalies.length})</option>
            <option value="critical">Critical Only</option>
            <option value="warning">Warning Only</option>
          </select>
        </div>
      </div>

      {/* Anomaly Feed */}
      <div className="space-y-4">
        {filtered.map((anomaly) => {
          const isCritical = anomaly.severity === 'critical';
          const isAcknowledged = anomaly.status === 'acknowledged';

          return (
            <div
              key={anomaly.id}
              className={`p-5 rounded-2xl border transition-all ${
                isCritical
                  ? 'bg-rose-950/20 border-rose-600/40 shadow-lg shadow-rose-950/20'
                  : 'bg-zinc-900/60 border-zinc-800'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-zinc-800/80 pb-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-xl ${
                      isCritical ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold font-mono text-white">{anomaly.deviceName}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold uppercase ${
                          isCritical
                            ? 'bg-rose-500 text-white'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {anomaly.severity} (Score: {anomaly.anomalyScore})
                      </span>
                    </div>
                    <span className="text-xs text-zinc-400 font-mono">
                      Anomaly ID: {anomaly.id} • {anomaly.timestamp}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {!isAcknowledged ? (
                    <button
                      onClick={() => acknowledgeAnomaly(anomaly.id)}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-mono font-semibold rounded-lg transition-colors flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Acknowledge</span>
                    </button>
                  ) : (
                    <span className="text-xs font-mono text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Acknowledged
                    </span>
                  )}

                  <button
                    onClick={() => onGenerateWorkOrder(anomaly)}
                    className="px-3.5 py-1.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-mono font-semibold rounded-lg transition-all flex items-center gap-1.5"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Generate Work Order</span>
                  </button>
                </div>
              </div>

              {/* Anomaly Breakdown Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 text-xs font-mono">
                <div className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-xl space-y-1">
                  <span className="text-zinc-500 text-[10px] uppercase">Telemetry Metric Deviation</span>
                  <div className="text-zinc-200 font-bold">{anomaly.metric}</div>
                  <div className="text-rose-400">
                    Current: <strong>{anomaly.currentValue}</strong> (Expected: {anomaly.expectedRange})
                  </div>
                </div>

                <div className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-xl space-y-1">
                  <span className="text-zinc-500 text-[10px] uppercase">Root Cause Diagnostic</span>
                  <div className="text-zinc-200">{anomaly.possibleCause}</div>
                </div>
              </div>

              {/* Action Recommendation */}
              <div className="mt-3 p-3 bg-orange-500/10 border border-orange-500/30 rounded-xl flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-orange-400 shrink-0" />
                  <span className="text-zinc-200">
                    <strong>Recommended Action:</strong> {anomaly.recommendedAction}
                  </span>
                </div>
                <button
                  onClick={() => setActiveView('root-cause')}
                  className="text-orange-400 hover:text-orange-300 font-mono font-bold uppercase text-[11px] shrink-0"
                >
                  Trace Causal Graph →
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
