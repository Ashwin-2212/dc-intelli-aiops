import React, { useState } from 'react';
import {
  Zap,
  Gauge,
  DollarSign,
  TrendingDown,
  Sparkles,
  ShieldCheck,
  Leaf,
  Layers,
  ArrowRight,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { TelemetryEngine, initialEnergyInsights } from '../services/telemetrySimulator';

export const PowerEnergyView: React.FC = () => {
  const engine = TelemetryEngine.getInstance();
  const facility = engine.facilities[0];
  const [electricityRate, setElectricityRate] = useState<number>(0.12);
  const [appliedInsights, setAppliedInsights] = useState<string[]>([]);

  const itPower = facility.itEquipmentPowerKw || 601.8;
  const coolingPower = facility.coolingPowerKw || 185.2;
  const totalPower = facility.totalFacilityPowerKw || 842.5;
  const pue = facility.pue || 1.40;

  // Monthly cost = kW * 24h * 30.5d * rate
  const monthlyCost = Math.round(totalPower * 24 * 30.5 * electricityRate);
  const annualCost = Math.round(monthlyCost * 12);
  const annualCo2Tons = +((totalPower * 24 * 365 * (facility.carbonIntensityGramsPerKwh || 380)) / 1000000).toFixed(1);

  const toggleApplyInsight = (id: string) => {
    if (appliedInsights.includes(id)) {
      setAppliedInsights(appliedInsights.filter((i) => i !== id));
    } else {
      setAppliedInsights([...appliedInsights, id]);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono">
              Power Distribution & Energy Intelligence (PUE)
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 font-mono font-bold">
              Substation Feed A+B
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time power quality harmonics, Power Usage Effectiveness (PUE), carbon emissions, and cost optimization.
          </p>
        </div>

        {/* Electricity Rate Configurator */}
        <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-3 py-2 rounded-xl text-xs font-mono">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <span className="text-zinc-400">Rate:</span>
          <input
            type="number"
            step="0.01"
            value={electricityRate}
            onChange={(e) => setElectricityRate(parseFloat(e.target.value) || 0.01)}
            className="w-16 bg-zinc-800 text-white font-bold px-1.5 py-0.5 rounded border border-zinc-700 focus:outline-none"
          />
          <span className="text-zinc-400">/ kWh</span>
        </div>
      </div>

      {/* Primary KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* PUE Score Card */}
        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span className="uppercase">Power Usage Effectiveness</span>
            <Gauge className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-white">
            {pue.toFixed(2)}{' '}
            <span className="text-xs font-semibold text-emerald-400 font-sans">
              {pue < 1.3 ? 'Excellent' : pue < 1.5 ? 'Good' : 'Suboptimal'}
            </span>
          </div>
          <p className="text-[11px] text-zinc-400 font-mono">
            Formula: Total Facility ({totalPower} kW) ÷ IT Load ({itPower} kW)
          </p>
        </div>

        {/* Monthly Cost */}
        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span className="uppercase">Monthly Electricity OpEx</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-emerald-400">
            ${monthlyCost.toLocaleString()}
          </div>
          <p className="text-[11px] text-zinc-400 font-mono">
            Annual Projection: ${annualCost.toLocaleString()}
          </p>
        </div>

        {/* Carbon Footprint */}
        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span className="uppercase">Carbon Emissions</span>
            <Leaf className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-white">
            {annualCo2Tons} <span className="text-xs font-normal text-zinc-400">Tons CO₂e/yr</span>
          </div>
          <p className="text-[11px] text-zinc-400 font-mono">
            Grid Intensity: {facility.carbonIntensityGramsPerKwh} g CO₂/kWh
          </p>
        </div>

        {/* IT vs Facility Power Ratio */}
        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span className="uppercase">IT Energy Efficiency</span>
            <Zap className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-white">
            {Math.round((itPower / totalPower) * 100)}%
          </div>
          <p className="text-[11px] text-zinc-400 font-mono">
            Useful Compute Power vs Infrastructure Overhead
          </p>
        </div>
      </div>

      {/* Power Topology Flow Diagram */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-orange-400" />
          Facility Power Topology (Substation to Server Rail)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center font-mono text-xs">
          {/* Step 1 */}
          <div className="p-3 bg-zinc-900 border border-zinc-700 rounded-xl space-y-1">
            <div className="text-[10px] text-zinc-500 uppercase">Utility Grid 13.8kV</div>
            <div className="text-sm font-bold text-white">Substation A+B</div>
            <div className="text-emerald-400 text-[11px]">99.999% Availability</div>
          </div>

          {/* Arrow */}
          <div className="hidden md:flex justify-center text-zinc-600 font-bold">➔</div>

          {/* Step 2 */}
          <div className="p-3 bg-zinc-900 border border-zinc-700 rounded-xl space-y-1">
            <div className="text-[10px] text-zinc-500 uppercase">Transformer 480V</div>
            <div className="text-sm font-bold text-white">2x 1500 kVA</div>
            <div className="text-zinc-300 text-[11px]">Load: 58%</div>
          </div>

          {/* Arrow */}
          <div className="hidden md:flex justify-center text-zinc-600 font-bold">➔</div>

          {/* Step 3 */}
          <div className="p-3 bg-zinc-900 border border-zinc-700 rounded-xl space-y-1">
            <div className="text-[10px] text-zinc-500 uppercase">UPS Inverter Buses</div>
            <div className="text-sm font-bold text-cyan-400">N+1 Redundant</div>
            <div className="text-emerald-400 text-[11px]">34 Min Reserve</div>
          </div>
        </div>
      </div>

      {/* AI Energy Optimization Action Recommendations */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-orange-400" />
              AI Energy Optimization Opportunities
            </h3>
            <p className="text-xs text-zinc-400">
              Validated non-disruptive recommendations to reduce kWh consumption and improve PUE.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-bold">
            Potential Monthly Savings: $3,239.00
          </span>
        </div>

        <div className="space-y-3">
          {initialEnergyInsights.map((insight) => {
            const isApplied = appliedInsights.includes(insight.id);
            return (
              <div
                key={insight.id}
                className={`p-4 rounded-xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  isApplied
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                    : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-mono text-orange-400 uppercase">
                      {insight.targetAsset}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">
                      Effort: {insight.implementationEffort}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-200">{insight.description}</p>
                </div>

                <div className="flex items-center gap-4 shrink-0 font-mono text-xs">
                  <div className="text-right">
                    <div className="font-bold text-emerald-400">
                      -${insight.monthlyCostSavings.toFixed(2)}/mo
                    </div>
                    <div className="text-[10px] text-zinc-400">-{insight.potentialPowerSavingsKw} kW Power</div>
                  </div>

                  <button
                    onClick={() => toggleApplyInsight(insight.id)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all ${
                      isApplied
                        ? 'bg-emerald-600 text-white'
                        : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                    }`}
                  >
                    {isApplied ? 'Applied ✓' : 'Execute Optimization'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
