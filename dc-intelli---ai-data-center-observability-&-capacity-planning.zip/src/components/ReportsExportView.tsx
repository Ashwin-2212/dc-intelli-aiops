import React, { useState } from 'react';
import {
  FileText,
  Download,
  Calendar,
  CheckCircle,
  Clock,
  Printer,
  Table,
  Zap,
  ShieldCheck,
  Share2,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';

export const ReportsExportView: React.FC = () => {
  const engine = TelemetryEngine.getInstance();
  const facility = engine.facilities[0];
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const triggerDownload = (format: 'json' | 'csv' | 'pdf', filename: string) => {
    let content = '';
    let mimeType = 'text/plain';

    if (format === 'json') {
      content = JSON.stringify(
        {
          timestamp: new Date().toISOString(),
          facility: engine.facilities,
          racks: engine.racks,
          coolingUnits: engine.coolingUnits,
          upsUnits: engine.upsUnits,
          anomalies: engine.anomalies,
          predictions: engine.predictions,
        },
        null,
        2
      );
      mimeType = 'application/json';
    } else if (format === 'csv') {
      const rows = [
        ['Rack_ID', 'Zone', 'Inlet_Temp_C', 'Outlet_Temp_C', 'Power_kW', 'U_Occupancy', 'Health_Score', 'Status'],
        ...engine.racks.map((r) => [
          r.id,
          r.zone,
          r.inletTempC,
          r.outletTempC,
          r.currentPowerKw,
          `${r.usedU}/${r.maxU}`,
          r.healthScore,
          r.status,
        ]),
      ];
      content = rows.map((e) => e.join(',')).join('\n');
      mimeType = 'text/csv';
    } else {
      // PDF mock trigger via printable window / Blob
      window.print();
      setDownloadSuccess('Report printed to PDF document successfully!');
      setTimeout(() => setDownloadSuccess(null), 3000);
      return;
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.${format}`;
    a.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess(`Exported ${filename}.${format} successfully!`);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono flex items-center gap-2">
              <FileText className="w-5 h-5 text-orange-400" />
              Executive Audit Reports & Telemetry Data Export
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono font-bold">
              ISO 50001 & ASHRAE TC 9.9 Compliant
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Generate formal facility SLA certification reports, energy audit statements, and export high-frequency raw telemetry arrays.
          </p>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs font-mono flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Available Report Types */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Report 1 */}
        <div className="p-5 bg-[#0a0a0a] border border-zinc-800 rounded-2xl space-y-4 shadow-xl">
          <div className="p-3 bg-zinc-900 rounded-xl text-orange-400 w-fit">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold font-mono text-white">
            Monthly PUE & Sustainability Audit
          </h3>
          <p className="text-xs text-zinc-400 font-mono">
            Comprehensive breakdown of total IT energy (kWh), chiller plant COP efficiency, carbon intensity footprint, and Scope 2 emissions.
          </p>
          <div className="pt-2 flex items-center gap-2">
            <button
              onClick={() => triggerDownload('pdf', 'DC-Intelli_PUE_Sustainability_Audit')}
              className="flex-1 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-mono font-bold rounded-xl flex items-center justify-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print PDF</span>
            </button>
            <button
              onClick={() => triggerDownload('json', 'DC-Intelli_PUE_Metrics')}
              className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono font-bold rounded-xl"
            >
              JSON
            </button>
          </div>
        </div>

        {/* Report 2 */}
        <div className="p-5 bg-[#0a0a0a] border border-zinc-800 rounded-2xl space-y-4 shadow-xl">
          <div className="p-3 bg-zinc-900 rounded-xl text-cyan-400 w-fit">
            <Table className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold font-mono text-white">
            42U Rack & Server Inventory Telemetry
          </h3>
          <p className="text-xs text-zinc-400 font-mono">
            Full tabular snapshot of all 12 rack elevations, installed server chassis, serial numbers, CPU temperatures, and live wattages.
          </p>
          <div className="pt-2 flex items-center gap-2">
            <button
              onClick={() => triggerDownload('csv', 'DC-Intelli_Rack_Server_Fleet_Inventory')}
              className="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-bold rounded-xl flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => triggerDownload('json', 'DC-Intelli_Server_Inventory')}
              className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono font-bold rounded-xl"
            >
              JSON
            </button>
          </div>
        </div>

        {/* Report 3 */}
        <div className="p-5 bg-[#0a0a0a] border border-zinc-800 rounded-2xl space-y-4 shadow-xl">
          <div className="p-3 bg-zinc-900 rounded-xl text-emerald-400 w-fit">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold font-mono text-white">
            ASHRAE Thermal Compliance & MTBF
          </h3>
          <p className="text-xs text-zinc-400 font-mono">
            Analysis of cold aisle air supply envelopes (18–27°C), CRAC fan velocity metrics, and predictive failure countdown logs.
          </p>
          <div className="pt-2 flex items-center gap-2">
            <button
              onClick={() => triggerDownload('pdf', 'DC-Intelli_ASHRAE_Compliance_Report')}
              className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono font-bold rounded-xl flex items-center justify-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print PDF</span>
            </button>
            <button
              onClick={() => triggerDownload('csv', 'DC-Intelli_Thermal_Anomalies')}
              className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono font-bold rounded-xl"
            >
              CSV
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
