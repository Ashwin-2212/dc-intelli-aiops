import React, { useState } from 'react';
import {
  TrendingUp,
  Calendar,
  Zap,
  HardDrive,
  Cpu,
  Layers,
  Sparkles,
  AlertTriangle,
  ArrowRight,
  DollarSign,
} from 'lucide-react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { generateCapacityForecast } from '../services/aiEngine';

export const CapacityPlanningView: React.FC = () => {
  const [timeHorizon, setTimeHorizon] = useState<'7d' | '30d' | '90d' | '180d' | '365d'>('90d');
  const forecastData = generateCapacityForecast(timeHorizon);

  const lastPoint = forecastData[forecastData.length - 1] || forecastData[0];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header & Horizon Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-400" />
              Intelligent Capacity Planning & Time-Series Forecasting
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 font-mono font-bold">
              Holt-Winters & Polynomial Regression
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Predictive forecasting of compute demand, substation power ceiling, thermal headroom, and rack U-space.
          </p>
        </div>

        {/* Time Horizon Buttons */}
        <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-xl gap-1">
          {(['7d', '30d', '90d', '180d', '365d'] as const).map((h) => (
            <button
              key={h}
              onClick={() => setTimeHorizon(h)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                timeHorizon === h
                  ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {h.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Forecast KPI Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span>Projected Power ({timeHorizon})</span>
            <Zap className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {lastPoint.powerDemandKw} <span className="text-xs font-normal text-zinc-400">kW</span>
          </div>
          <span className="text-[11px] text-amber-400 font-mono">
            {Math.round((lastPoint.powerDemandKw / lastPoint.powerCapacityLimitKw) * 100)}% of 1,100 kW Transformer Cap
          </span>
        </div>

        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span>Storage Exhaustion Horizon</span>
            <HardDrive className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400">
            {lastPoint.storageCapacityPercent}% <span className="text-xs font-normal text-zinc-400">Filled</span>
          </div>
          <span className="text-[11px] text-zinc-400 font-mono">
            Expansion required within 54 days
          </span>
        </div>

        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span>Rack Occupancy</span>
            <Layers className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {lastPoint.rackOccupancyPercent}%
          </div>
          <span className="text-[11px] text-emerald-400 font-mono">
            32U contiguous bays available
          </span>
        </div>

        <div className="p-4 bg-[#0a0a0a] border border-zinc-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-mono">
            <span>Projected Monthly OpEx</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            ${lastPoint.projectedCost.toLocaleString()}
          </div>
          <span className="text-[11px] text-zinc-400 font-mono">
            +${(lastPoint.projectedCost - 72500).toLocaleString()} vs Current Baseline
          </span>
        </div>
      </div>

      {/* Main Multi-Metric Forecast Chart */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">
              {timeHorizon.toUpperCase()} Multi-Resource Utilization Projections
            </h3>
            <p className="text-xs text-zinc-400">Compute (CPU), Storage (TB), and Power Demand (kW) Forecast Curves</p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-orange-400">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span> CPU Capacity (%)
            </span>
            <span className="flex items-center gap-1.5 text-cyan-400">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Storage Capacity (%)
            </span>
            <span className="flex items-center gap-1.5 text-purple-400">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-400"></span> Power Demand (kW)
            </span>
          </div>
        </div>

        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={forecastData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
              <XAxis dataKey="date" stroke="#71717a" fontSize={11} fontStyle="mono" />
              <YAxis stroke="#71717a" fontSize={11} fontStyle="mono" />
              <Tooltip
                contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
              />
              <Line type="monotone" dataKey="cpuCapacityPercent" stroke="#f97316" strokeWidth={2.5} dot={false} name="CPU %" />
              <Line type="monotone" dataKey="storageCapacityPercent" stroke="#22d3ee" strokeWidth={2.5} dot={false} name="Storage %" />
              <Line type="monotone" dataKey="powerDemandKw" stroke="#c084fc" strokeWidth={2} strokeDasharray="4 4" dot={false} name="Power (kW)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Capacity Advisor Recommendations */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold font-mono text-white uppercase tracking-wider">
          <Sparkles className="w-4 h-4 text-orange-400" />
          AI Capacity Advisor Automated Procurement & Allocation Directives
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-orange-400 font-bold">
              <span>Compute & Storage Expansion</span>
              <span className="text-[10px] bg-orange-500/20 text-orange-300 px-2 py-0.5 rounded">60-Day Action</span>
            </div>
            <p className="text-zinc-300">
              Procure 2x High-Density All-Flash Storage Arrays (64TB NVMe-oF) for Zone B to prevent database I/O saturation prior to Q4 customer load spikes.
            </p>
          </div>

          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-400 font-bold">
              <span>Power Substation Headroom</span>
              <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded">90-Day Action</span>
            </div>
            <p className="text-zinc-300">
              Transformer 1 load is projected to reach 88% by month 3. Activate Transformer 2 automatic load-balancing bus tie breaker during off-peak maintenance.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
