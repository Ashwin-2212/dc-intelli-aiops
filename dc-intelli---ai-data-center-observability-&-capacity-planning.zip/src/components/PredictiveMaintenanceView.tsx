import React from 'react';
import {
  Flame,
  Clock,
  ShieldAlert,
  Sparkles,
  Wrench,
  Activity,
  CheckCircle,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';
import { PredictiveFailureRecord } from '../types';

interface PredictiveMaintenanceViewProps {
  onGenerateWorkOrder: (item: any) => void;
}

export const PredictiveMaintenanceView: React.FC<PredictiveMaintenanceViewProps> = ({
  onGenerateWorkOrder,
}) => {
  const engine = TelemetryEngine.getInstance();
  const predictions = engine.predictions;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              Predictive Equipment Failure & Degradation Engine
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono font-bold">
              Random Forest & Degradation ML
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Forecasting hardware and mechanical component failures 8 to 45 days in advance using acoustic vibration, thermal stress, and SMART telemetry.
          </p>
        </div>
      </div>

      {/* Predictions Grid */}
      <div className="space-y-4">
        {predictions.map((pred) => {
          const isCritical = pred.riskLevel === 'critical';
          const isHigh = pred.riskLevel === 'high';

          return (
            <div
              key={pred.id}
              className={`p-5 rounded-2xl border transition-all ${
                isCritical
                  ? 'bg-rose-950/20 border-rose-600/50 shadow-xl'
                  : isHigh
                  ? 'bg-amber-950/20 border-amber-500/40'
                  : 'bg-zinc-900/60 border-zinc-800'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold font-mono text-white">{pred.deviceName}</span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-mono uppercase font-bold ${
                        isCritical
                          ? 'bg-rose-500 text-white'
                          : isHigh
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-blue-500/20 text-blue-300'
                      }`}
                    >
                      {pred.failureProbability}% Failure Risk ({pred.riskLevel})
                    </span>
                  </div>
                  <span className="text-xs text-zinc-400 font-mono">
                    Target Sub-Component: <strong className="text-zinc-200">{pred.component}</strong>
                  </span>
                </div>

                <button
                  onClick={() => onGenerateWorkOrder(pred)}
                  className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-mono font-semibold rounded-lg shadow-sm transition-all flex items-center gap-1.5 shrink-0"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>Schedule Preventive Work Order</span>
                </button>
              </div>

              {/* Time Horizon & Reliability Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 my-4 font-mono text-xs">
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                  <span className="text-zinc-500 text-[10px]">Predicted Failure Window</span>
                  <div className="text-sm font-bold text-amber-400 mt-1">{pred.expectedWindowDays}</div>
                </div>
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                  <span className="text-zinc-500 text-[10px]">Model Confidence</span>
                  <div className="text-sm font-bold text-emerald-400 mt-1">{pred.confidencePercent}% Confidence</div>
                </div>
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                  <span className="text-zinc-500 text-[10px]">Asset MTBF</span>
                  <div className="text-sm font-bold text-white mt-1">{pred.mtbfHours.toLocaleString()} Hours</div>
                </div>
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                  <span className="text-zinc-500 text-[10px]">Estimated MTTR</span>
                  <div className="text-sm font-bold text-cyan-400 mt-1">{pred.mttrHours} Hours</div>
                </div>
              </div>

              {/* Explainable AI Contributing Factors */}
              <div className="p-4 bg-zinc-900/80 border border-zinc-800 rounded-xl space-y-2">
                <div className="text-xs font-mono font-semibold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-orange-400" />
                  Explainable AI (XAI) Contributing Failure Factors
                </div>

                <div className="space-y-2 pt-1">
                  {pred.factors.map((f, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-mono text-zinc-300">
                        <span>{f.factor}</span>
                        <span className="font-bold text-orange-400">+{f.contributionPercent}%</span>
                      </div>
                      <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-orange-500 to-amber-500"
                          style={{ width: `${f.contributionPercent}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Recommendation */}
              <div className="mt-3 p-3 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-zinc-200 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong>AIOps Guidance:</strong> {pred.recommendation}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
