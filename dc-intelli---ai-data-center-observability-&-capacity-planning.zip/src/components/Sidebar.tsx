import React from 'react';
import {
  Activity,
  Layers,
  Server,
  Cpu,
  Thermometer,
  Zap,
  BatteryCharging,
  AlertTriangle,
  Flame,
  TrendingUp,
  SlidersHorizontal,
  FileText,
  ShieldCheck,
  Settings,
  GitBranch,
  Wrench,
  Boxes,
  Crown,
  Briefcase,
  Monitor,
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  currentRole?: UserRole;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  setActiveView,
  currentRole = 'super_admin',
}) => {
  const roleSections = [
    {
      title: 'Role Command Centers',
      items: [
        {
          id: 'super-admin',
          label: 'Super Admin HQ',
          icon: Crown,
          badge: 'Supreme',
          superAdminOnly: true,
          color: 'text-purple-400',
        },
        {
          id: 'manager-cockpit',
          label: 'Manager Cockpit',
          icon: Briefcase,
          color: 'text-blue-400',
        },
        {
          id: 'engineer-diag',
          label: 'Engineer Diagnostics',
          icon: Wrench,
          color: 'text-emerald-400',
        },
        {
          id: 'operator-noc',
          label: 'Operator NOC Live',
          icon: Monitor,
          color: 'text-amber-400',
        },
      ],
    },
    {
      title: 'Observability & Twin',
      items: [
        { id: 'overview', label: 'Live Overview', icon: Activity },
        { id: 'digital-twin', label: 'Visual Digital Twin', icon: Layers },
        { id: 'racks', label: 'Rack Matrix (42U)', icon: Boxes },
        { id: 'servers', label: 'Server Fleet', icon: Server },
        { id: 'cooling', label: 'Cooling Intelligence', icon: Thermometer },
        { id: 'power', label: 'Power & PUE', icon: Zap },
        { id: 'ups', label: 'UPS Battery Banks', icon: BatteryCharging },
      ],
    },
    {
      title: 'Intelligence & AIOps',
      items: [
        { id: 'anomalies', label: 'AI Anomaly Radar', icon: AlertTriangle, badge: 'Live' },
        { id: 'predictive', label: 'Predictive Failure', icon: Flame },
        { id: 'capacity', label: 'Capacity Runway', icon: TrendingUp },
        { id: 'what-if', label: 'What-If Sandbox', icon: SlidersHorizontal },
        { id: 'root-cause', label: 'Root Cause Graph', icon: GitBranch },
        { id: 'energy-optimizer', label: 'Energy Optimizer', icon: Zap },
      ],
    },
    {
      title: 'Governance & Security',
      items: [
        { id: 'incidents', label: 'Work Orders & SLA', icon: Wrench },
        { id: 'reports', label: 'Audit Reports & PDF', icon: FileText },
        { id: 'security', label: 'RBAC Security & Policy', icon: ShieldCheck },
      ],
    },
  ];

  const getRoleBadge = (role?: string | UserRole) => {
    switch (role) {
      case 'super_admin':
        return { label: 'SUPER ADMIN (ROOT)', color: 'bg-purple-950/80 text-purple-300 border-purple-600' };
      case 'dc_admin':
        return { label: 'DC SITE ADMIN', color: 'bg-orange-950/80 text-orange-300 border-orange-600' };
      case 'manager':
        return { label: 'OPERATIONS MANAGER', color: 'bg-blue-950/80 text-blue-300 border-blue-600' };
      case 'engineer':
        return { label: 'LEAD INFRA ENGINEER', color: 'bg-emerald-950/80 text-emerald-300 border-emerald-600' };
      case 'technician':
        return { label: 'NOC TECHNICIAN', color: 'bg-amber-950/80 text-amber-300 border-amber-600' };
      default:
        return { label: 'VIEWER / READ-ONLY', color: 'bg-zinc-800 text-zinc-400 border-zinc-700' };
    }
  };

  const currentBadge = getRoleBadge(currentRole);

  return (
    <aside className="w-64 bg-[#0a0a0c] border-r border-zinc-800/80 flex flex-col h-full shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-4 flex items-center justify-between border-b border-zinc-800/80">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-600 via-orange-500 to-amber-500 rounded-lg flex items-center justify-center shadow-lg shadow-purple-500/20">
            <Crown className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-white font-bold tracking-tight text-base">DC-Intelli</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono font-bold border border-purple-500/30">
                PRO
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 font-mono">Autonomous DCIM</p>
          </div>
        </div>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4 custom-scrollbar">
        {roleSections.map((section) => (
          <div key={section.title} className="space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold px-3 py-1 font-mono">
              {section.title}
            </div>

            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              const isSuper = (item as any).superAdminOnly;

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group ${
                    isActive
                      ? isSuper
                        ? 'bg-purple-950/90 text-purple-200 border border-purple-500/80 shadow-md shadow-purple-950 font-bold'
                        : 'bg-zinc-800/90 text-white border border-zinc-700/80 shadow-xs'
                      : isSuper
                      ? 'text-purple-300 hover:bg-purple-950/30 border border-purple-900/30'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon
                      className={`w-4 h-4 transition-colors ${
                        isActive
                          ? isSuper
                            ? 'text-amber-400'
                            : 'text-orange-400'
                          : (item as any).color || 'text-zinc-400 group-hover:text-zinc-200'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded-full font-bold border ${
                        item.badge === 'Supreme'
                          ? 'bg-purple-900/80 text-purple-200 border-purple-500'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Role Profile Box at Bottom */}
      <div className="p-3 border-t border-zinc-800/80 bg-[#09090c]">
        <div className="p-2.5 bg-zinc-900/80 border border-zinc-800/70 rounded-xl space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-zinc-400 uppercase font-mono font-bold tracking-wider">
              System Authority
            </span>
            <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${currentBadge.color}`}>
              {currentBadge.label}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div
              className={`w-7 h-7 rounded-lg border flex items-center justify-center text-xs font-bold ${
                currentRole === 'super_admin'
                  ? 'bg-purple-950 border-purple-500 text-amber-400'
                  : 'bg-zinc-800 border-zinc-700 text-orange-400'
              }`}
            >
              {currentRole === 'super_admin' ? <Crown className="w-3.5 h-3.5 fill-amber-400" /> : (currentRole || 'admin').slice(0, 2).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-zinc-200 truncate">
                {currentRole === 'super_admin' ? 'Dr. Evelyn Vance' : 'Ashwin Surya'}
              </div>
              <div className="text-[10px] text-zinc-400 truncate">
                {currentRole === 'super_admin' ? 'Root Authority / Global DCIM' : 'NOC Lead Operator'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
