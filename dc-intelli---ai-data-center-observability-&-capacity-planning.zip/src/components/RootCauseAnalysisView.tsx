import React from 'react';
import {
  GitBranch,
  AlertTriangle,
  Flame,
  CheckCircle2,
  Sparkles,
  Wrench,
  Layers,
  ArrowRight,
  ShieldCheck,
  Server,
  Wind,
} from 'lucide-react';
import { analyzeRootCause } from '../services/aiEngine';
import { TelemetryEngine } from '../services/telemetrySimulator';

interface RootCauseAnalysisViewProps {
  onGenerateWorkOrder: (item: any) => void;
}

export const RootCauseAnalysisView: React.FC<RootCauseAnalysisViewProps> = ({
  onGenerateWorkOrder,
}) => {
  const engine = TelemetryEngine.getInstance();
  const analysis = analyzeRootCause(engine.anomalies, engine.coolingUnits, engine.racks);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono flex items-center gap-2">
              <GitBranch className="w-5 h-5 text-orange-400" />
              AI Root Cause Analysis & Incident Causal Graph
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-mono font-bold">
              Multi-Tier Alert Correlation
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Correlating 40+ concurrent telemetry alerts into a single deterministic root cause incident chain to eliminate alert fatigue.
          </p>
        </div>

        <button
          onClick={() =>
            onGenerateWorkOrder({
              deviceId: 'CRAC-02',
              deviceName: analysis.probableRootCause,
              metric: 'Root Cause Incident Mitigation',
              severity: 'critical',
            })
          }
          className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-mono font-semibold rounded-xl shadow-sm transition-all flex items-center gap-2 self-start md:self-auto"
        >
          <Wrench className="w-4 h-4" />
          <span>Dispatch Emergency Work Order</span>
        </button>
      </div>

      {/* Root Cause Banner */}
      <div className="p-5 bg-rose-950/20 border border-rose-600/40 rounded-2xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-rose-500/20 pb-3">
          <div>
            <span className="text-[10px] uppercase font-mono font-bold text-rose-400 tracking-wider">
              Probable Root Cause Detected
            </span>
            <h2 className="text-lg font-bold font-mono text-white mt-0.5">
              {analysis.probableRootCause}
            </h2>
          </div>
          <div className="flex items-center gap-3 font-mono text-xs">
            <span className="px-3 py-1 bg-rose-500 text-white font-bold rounded-lg uppercase">
              {analysis.confidence}% Confidence
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs pt-1">
          <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-xl">
            <span className="text-zinc-500 text-[10px]">Affected Racks</span>
            <div className="text-sm font-bold text-white mt-1">{analysis.affectedRacks.join(', ')}</div>
          </div>
          <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-xl">
            <span className="text-zinc-500 text-[10px]">Impacted Compute Nodes</span>
            <div className="text-sm font-bold text-rose-400 mt-1">{analysis.affectedServersCount} Servers</div>
          </div>
          <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-xl">
            <span className="text-zinc-500 text-[10px]">Localized Thermal Delta</span>
            <div className="text-sm font-bold text-amber-400 mt-1">+6.8°C Inlet Elevation</div>
          </div>
        </div>
      </div>

      {/* Causal Event Cascade Tree */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-orange-400" />
          Incident Propagation Sequence (Physical to Logical Cascade)
        </h3>

        <div className="relative pl-6 space-y-6 before:content-[''] before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gradient-to-b before:from-rose-500 before:via-amber-500 before:to-emerald-500">
          {analysis.incidentChain.map((step, idx) => (
            <div key={idx} className="relative flex items-start gap-4 group">
              {/* Node Indicator */}
              <div
                className={`absolute -left-6 w-5 h-5 rounded-full border-2 border-black flex items-center justify-center text-[10px] font-mono font-bold ${
                  idx === 0
                    ? 'bg-rose-500 text-white'
                    : idx === analysis.incidentChain.length - 1
                    ? 'bg-amber-500 text-black'
                    : 'bg-zinc-800 text-zinc-300'
                }`}
              >
                {idx + 1}
              </div>

              <div className="flex-1 p-3.5 bg-zinc-900/70 border border-zinc-800 rounded-xl font-mono text-xs text-zinc-200">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider block mb-1">
                  {idx === 0 ? 'Primary Mechanical Failure' : idx === 1 ? 'Thermal Aerodynamic Impact' : idx === 2 ? 'Cold-Aisle Degradation' : 'Compute & Application Impact'}
                </span>
                {step}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Actionable Step-by-Step Mitigation Plan */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          Recommended Multi-Step Mitigation Playbook
        </h3>

        <div className="space-y-3 font-mono text-xs">
          {analysis.mitigationSteps.map((step, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-zinc-900/60 border border-zinc-800 rounded-xl flex items-center gap-3"
            >
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                {idx + 1}
              </div>
              <span className="text-zinc-200 flex-1">{step}</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 uppercase font-semibold">
                Priority
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
