import React, { useState } from 'react';
import {
  SlidersHorizontal,
  Zap,
  DollarSign,
  Gauge,
  Boxes,
  Thermometer,
  Sparkles,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Play,
  RotateCcw,
} from 'lucide-react';
import { calculateWhatIfImpact } from '../services/aiEngine';
import { TelemetryEngine } from '../services/telemetrySimulator';
import { WhatIfScenarioInput } from '../types';

export const WhatIfSandbox: React.FC = () => {
  const engine = TelemetryEngine.getInstance();
  const facility = engine.facilities[0];

  const [input, setInput] = useState<WhatIfScenarioInput>({
    additionalServers: 24,
    avgCpuLoadPercent: 75,
    perServerPowerWatts: 550,
    electricityRate: 0.12,
    coolingEfficiencyFactor: 3.5,
    plannedWorkloadType: 'AI Training Cluster (NVIDIA HGX / Dual Xeon)',
  });

  const currentTotalKw = facility.totalFacilityPowerKw || 842.5;
  const currentItKw = facility.itEquipmentPowerKw || 601.8;
  const currentPue = facility.pue || 1.40;

  const result = calculateWhatIfImpact(input, currentTotalKw, currentItKw, currentPue);

  const resetDefaults = () => {
    setInput({
      additionalServers: 24,
      avgCpuLoadPercent: 75,
      perServerPowerWatts: 550,
      electricityRate: 0.12,
      coolingEfficiencyFactor: 3.5,
      plannedWorkloadType: 'AI Training Cluster (NVIDIA HGX / Dual Xeon)',
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-orange-400" />
              What-If Infrastructure Expansion Sandbox
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-mono font-bold">
              Thermodynamic & Power Simulator
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Simulate hardware additions, compute density surges, cooling COP changes, and projected PUE / OpEx impacts before physical deployment.
          </p>
        </div>

        <button
          onClick={resetDefaults}
          className="px-3.5 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs font-mono font-semibold rounded-xl transition-all flex items-center gap-1.5 self-start md:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Scenario</span>
        </button>
      </div>

      {/* Main Grid: Controls vs Simulated Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 5 Cols: Simulation Controls */}
        <div className="lg:col-span-5 bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-5">
          <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider border-b border-zinc-800 pb-3">
            Expansion Parameters
          </h3>

          {/* Additional Servers Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-zinc-300">
              <span>Additional Server Nodes:</span>
              <strong className="text-orange-400 text-sm">+{input.additionalServers} Servers</strong>
            </div>
            <input
              type="range"
              min="0"
              max="80"
              step="2"
              value={input.additionalServers}
              onChange={(e) =>
                setInput({ ...input, additionalServers: parseInt(e.target.value) || 0 })
              }
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
            />
            <div className="flex justify-between text-[10px] font-mono text-zinc-500">
              <span>0 (Baseline)</span>
              <span>40 Servers</span>
              <span>80 Servers</span>
            </div>
          </div>

          {/* Workload Profile Preset */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-zinc-400">Workload Profile / Server TDP:</label>
            <select
              value={input.perServerPowerWatts}
              onChange={(e) =>
                setInput({
                  ...input,
                  perServerPowerWatts: parseInt(e.target.value),
                  plannedWorkloadType:
                    e.target.value === '850'
                      ? 'AI Training Cluster (NVIDIA HGX)'
                      : e.target.value === '550'
                      ? 'Enterprise Compute (Dual Xeon/EPYC)'
                      : 'Storage Array (NVMe/SAS)',
                })
              }
              className="w-full bg-zinc-900 border border-zinc-700 text-xs font-mono text-white p-2.5 rounded-xl focus:outline-none focus:border-orange-500 cursor-pointer"
            >
              <option value="850">AI Training Cluster (850W per node)</option>
              <option value="550">Enterprise Compute / DB (550W per node)</option>
              <option value="320">Edge & Storage Array (320W per node)</option>
              <option value="200">Lightweight Web Tier (200W per node)</option>
            </select>
          </div>

          {/* Avg CPU Utilization */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-zinc-300">
              <span>Expected Average CPU Load:</span>
              <strong className="text-cyan-400">{input.avgCpuLoadPercent}%</strong>
            </div>
            <input
              type="range"
              min="20"
              max="100"
              step="5"
              value={input.avgCpuLoadPercent}
              onChange={(e) =>
                setInput({ ...input, avgCpuLoadPercent: parseInt(e.target.value) || 20 })
              }
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
          </div>

          {/* Cooling COP Factor */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-zinc-300">
              <span>Cooling Coefficient of Perf (COP):</span>
              <strong className="text-emerald-400">{input.coolingEfficiencyFactor} COP</strong>
            </div>
            <input
              type="range"
              min="2.5"
              max="4.5"
              step="0.1"
              value={input.coolingEfficiencyFactor}
              onChange={(e) =>
                setInput({
                  ...input,
                  coolingEfficiencyFactor: parseFloat(e.target.value) || 3.5,
                })
              }
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            <span className="text-[10px] text-zinc-500 font-mono">
              Higher COP = More efficient chiller plant
            </span>
          </div>
        </div>

        {/* Right 7 Cols: Real-time Simulation Results */}
        <div className="lg:col-span-7 space-y-5">
          {/* Top Result KPI Banner */}
          <div className="p-5 bg-[#0a0a0a] border border-zinc-800 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider">
                Simulated Facility Impact
              </span>
              <span
                className={`text-xs px-3 py-1 rounded-full font-mono uppercase font-bold ${
                  result.capacityRiskLevel === 'Critical'
                    ? 'bg-rose-500 text-white animate-pulse'
                    : result.capacityRiskLevel === 'High'
                    ? 'bg-amber-500/20 text-amber-300'
                    : result.capacityRiskLevel === 'Moderate'
                    ? 'bg-blue-500/20 text-blue-300'
                    : 'bg-emerald-500/20 text-emerald-300'
                }`}
              >
                Risk: {result.capacityRiskLevel}
              </span>
            </div>

            {/* 4 Outcome Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
                <span className="text-zinc-500 text-[10px]">Added IT Power</span>
                <div className="text-base font-bold text-orange-400 mt-1">
                  +{result.addedPowerKw} kW
                </div>
                <span className="text-[10px] text-zinc-400">
                  New Total: {result.newTotalPowerKw} kW
                </span>
              </div>

              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
                <span className="text-zinc-500 text-[10px]">Cooling Overhead</span>
                <div className="text-base font-bold text-cyan-400 mt-1">
                  +{result.addedCoolingKwRequired} kW
                </div>
                <span className="text-[10px] text-zinc-400">
                  Heat: +{(result.addedPowerKw * 3412).toLocaleString()} BTU/hr
                </span>
              </div>

              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
                <span className="text-zinc-500 text-[10px]">Projected PUE</span>
                <div className="text-base font-bold text-white mt-1">
                  {result.projectedPUE.toFixed(2)}{' '}
                  <span className="text-[10px] text-amber-400">
                    ({result.pueDelta >= 0 ? `+${result.pueDelta.toFixed(2)}` : result.pueDelta.toFixed(2)})
                  </span>
                </div>
              </div>

              <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl">
                <span className="text-zinc-500 text-[10px]">Monthly OpEx Δ</span>
                <div className="text-base font-bold text-emerald-400 mt-1">
                  +${result.monthlyCostIncrease.toLocaleString()}
                </div>
                <span className="text-[10px] text-zinc-400">At ${input.electricityRate}/kWh</span>
              </div>
            </div>

            {/* Racks and Space Requirements */}
            <div className="p-3 bg-zinc-900/60 border border-zinc-800 rounded-xl flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2 text-zinc-300">
                <Boxes className="w-4 h-4 text-orange-400" />
                <span>Physical Space Required: <strong>{result.requiredRacks} Racks</strong> ({input.additionalServers * 2}U total)</span>
              </div>
              <span className="text-emerald-400 font-semibold">{result.availableULeft}U Space Remaining in Floor</span>
            </div>
          </div>

          {/* AI Bottlenecks and Mitigation Directives */}
          <div className="p-5 bg-[#0a0a0a] border border-zinc-800 rounded-2xl space-y-3 font-mono text-xs">
            <h4 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-orange-400" />
              AI Architectural Feasibility & Bottleneck Analysis
            </h4>

            {result.bottlenecks.length > 0 ? (
              <div className="space-y-2 pt-1">
                {result.bottlenecks.map((b, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 flex items-center gap-2"
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span><strong>Identified Bottleneck:</strong> {b}</span>
                  </div>
                ))}

                {result.recommendations.map((rec, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-200 flex items-center gap-2"
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span><strong>Pre-Deployment Action:</strong> {rec}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>
                  Expansion is fully viable within current substation transformer headroom, chiller loop capacity, and 42U rack envelopes.
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
