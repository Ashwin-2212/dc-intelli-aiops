import React, { useState } from 'react';
import {
  Thermometer,
  Wind,
  Droplets,
  Zap,
  CheckCircle,
  AlertTriangle,
  Flame,
  Activity,
  Sliders,
  Settings2,
  TrendingDown,
  Info,
} from 'lucide-react';
import { TelemetryEngine } from '../services/telemetrySimulator';

export const CoolingIntelligenceView: React.FC = () => {
  const engine = TelemetryEngine.getInstance();
  const coolingUnits = engine.coolingUnits;
  const racks = engine.racks;

  const [coldAisleSetpoint, setColdAisleSetpoint] = useState<number>(20.5);

  const hotRacks = racks.filter((r) => r.inletTempC > 27 || r.status === 'critical');
  const avgCop = +(coolingUnits.reduce((acc, c) => acc + c.copEfficiency, 0) / coolingUnits.length).toFixed(2);
  const totalCoolingPower = +(coolingUnits.reduce((acc, c) => acc + c.powerDrawKw, 0)).toFixed(1);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0a0a] border border-zinc-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white font-mono">
              Cooling & Thermal Intelligence Center
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-mono font-bold">
              ASHRAE TC 9.9 Envelopes
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            CRAC air handlers, chilled water loops, CFM distribution, and predictive thermal hotspot telemetry.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center gap-3 text-xs font-mono">
            <div>
              <span className="text-zinc-500 text-[10px] uppercase">Average COP</span>
              <div className="text-base font-bold text-emerald-400">{avgCop}</div>
            </div>
            <div className="h-6 w-px bg-zinc-800"></div>
            <div>
              <span className="text-zinc-500 text-[10px] uppercase">Cooling Power</span>
              <div className="text-base font-bold text-cyan-400">{totalCoolingPower} kW</div>
            </div>
          </div>
        </div>
      </div>

      {/* Hotspots Warning Alert */}
      {hotRacks.length > 0 && (
        <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-rose-500/20 rounded-xl text-rose-400">
              <Flame className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h4 className="text-xs font-bold font-mono text-rose-300 uppercase">
                {hotRacks.length} Thermal Hotspots Detected in Zone A
              </h4>
              <p className="text-xs text-zinc-300">
                Racks {hotRacks.map((r) => r.id).join(', ')} inlet temperatures are exceeding 28.0°C. Upstream CRAC-02 fan velocity degradation suspected.
              </p>
            </div>
          </div>
          <button className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg font-mono uppercase tracking-wider shrink-0">
            Emergency Airflow Override
          </button>
        </div>
      )}

      {/* CRAC Units Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {coolingUnits.map((crac) => {
          const isCritical = crac.status === 'critical';
          const isWarning = crac.status === 'warning';
          return (
            <div
              key={crac.id}
              className={`p-4 bg-[#0a0a0a] border rounded-2xl space-y-3 transition-all ${
                isCritical
                  ? 'border-rose-500/70 shadow-lg shadow-rose-950/40 ring-1 ring-rose-500/40'
                  : isWarning
                  ? 'border-amber-500/60 shadow-lg shadow-amber-950/30'
                  : 'border-zinc-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold font-mono text-white flex items-center gap-1.5">
                  <Wind className={`w-4 h-4 ${isCritical ? 'text-rose-400' : 'text-cyan-400'}`} />
                  {crac.id}
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-mono uppercase font-bold ${
                    isCritical
                      ? 'bg-rose-500/20 text-rose-300'
                      : isWarning
                      ? 'bg-amber-500/20 text-amber-300'
                      : 'bg-emerald-500/20 text-emerald-300'
                  }`}
                >
                  {crac.status}
                </span>
              </div>

              <div className="text-[11px] text-zinc-400 font-mono">{crac.name}</div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2 bg-zinc-900 border border-zinc-800 rounded-lg">
                  <span className="text-zinc-500 text-[10px]">Supply Air</span>
                  <div className="font-bold text-white mt-0.5">{crac.supplyTempC}°C</div>
                </div>
                <div className="p-2 bg-zinc-900 border border-zinc-800 rounded-lg">
                  <span className="text-zinc-500 text-[10px]">Return Air</span>
                  <div className="font-bold text-white mt-0.5">{crac.returnTempC}°C</div>
                </div>
                <div className="p-2 bg-zinc-900 border border-zinc-800 rounded-lg">
                  <span className="text-zinc-500 text-[10px]">Chilled Water</span>
                  <div className="font-bold text-cyan-400 mt-0.5">{crac.chilledWaterFlowLpm} LPM</div>
                </div>
                <div className="p-2 bg-zinc-900 border border-zinc-800 rounded-lg">
                  <span className="text-zinc-500 text-[10px]">Power Load</span>
                  <div className="font-bold text-orange-400 mt-0.5">{crac.powerDrawKw} kW</div>
                </div>
              </div>

              {/* Fan Speed Bar */}
              <div>
                <div className="flex justify-between text-[11px] font-mono text-zinc-400 mb-1">
                  <span>Blower Fan Speed</span>
                  <span>{crac.fanSpeedPercent}%</span>
                </div>
                <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${crac.fanSpeedPercent > 90 ? 'bg-rose-500' : 'bg-cyan-400'}`}
                    style={{ width: `${crac.fanSpeedPercent}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Setpoint Optimizer & Airflow Control Card */}
      <div className="bg-[#0a0a0a] border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-orange-400" />
              Dynamic Setpoint & Cold-Aisle Temperature Optimizer
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Increasing cold aisle temperature by 1.0°C yields ~3.8% cooling energy savings without compromising server MTBF.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center pt-2">
          {/* Slider */}
          <div className="md:col-span-2 space-y-2">
            <div className="flex justify-between text-xs font-mono text-zinc-300">
              <span>Target Cold Aisle Supply: <strong className="text-orange-400">{coldAisleSetpoint}°C</strong></span>
              <span className="text-emerald-400">ASHRAE Recommended: 18°C – 27°C</span>
            </div>
            <input
              type="range"
              min="17"
              max="26"
              step="0.5"
              value={coldAisleSetpoint}
              onChange={(e) => setColdAisleSetpoint(parseFloat(e.target.value))}
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
            />
            <div className="flex justify-between text-[10px] font-mono text-zinc-500">
              <span>17.0°C (Overcooled / High OpEx)</span>
              <span>21.5°C (Optimal Balance)</span>
              <span>26.0°C (High Efficiency / Strict Monitoring)</span>
            </div>
          </div>

          {/* Real-time Projected Savings */}
          <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-2 font-mono text-xs">
            <div className="flex justify-between text-zinc-400">
              <span>Projected Power Savings:</span>
              <span className="text-emerald-400 font-bold">
                {+((coldAisleSetpoint - 18.5) * 12.4).toFixed(1)} kW
              </span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Monthly Cost Reduction:</span>
              <span className="text-emerald-400 font-bold">
                ${Math.max(0, Math.round((coldAisleSetpoint - 18.5) * 12.4 * 24 * 30.5 * 0.12))} / mo
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
