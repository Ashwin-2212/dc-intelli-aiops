import {
  CapacityForecastPoint,
  WhatIfScenarioInput,
  WhatIfScenarioResult,
  RackUnit,
  ServerDevice,
  CoolingUnit,
  UpsUnit,
  AnomalyRecord,
  PredictiveFailureRecord,
} from '../types';

// Multi-variate Anomaly Detection Engine
export function detectLiveAnomalies(
  servers: ServerDevice[],
  racks: RackUnit[],
  cooling: CoolingUnit[],
  ups: UpsUnit[]
): AnomalyRecord[] {
  const anomalies: AnomalyRecord[] = [];

  // Check servers for multi-metric deviations
  servers.forEach(server => {
    const { cpuUsage, cpuTemp, powerDrawWatts, networkLatencyMs } = server.telemetry;
    
    // Anomaly 1: High temp with moderate/high CPU
    if (cpuTemp > 76) {
      anomalies.push({
        id: `ANOM-${server.id}-${Date.now().toString().slice(-4)}`,
        timestamp: 'Just now',
        deviceId: server.id,
        deviceName: `${server.name} (${server.rackId})`,
        deviceType: 'server',
        metric: 'CPU Temperature & Thermal Stress',
        currentValue: `${cpuTemp}°C`,
        expectedRange: '35°C–65°C',
        anomalyScore: +Math.min(0.98, (cpuTemp - 55) / 30).toFixed(2),
        severity: cpuTemp > 82 ? 'critical' : 'warning',
        possibleCause: 'Inlet airflow restriction or upstream CRAC unit thermal degradation',
        recommendedAction: 'Inspect server heatsink fan velocity and verify cold aisle containment door seal',
        status: 'active',
      });
    }

    // Anomaly 2: Extreme CPU with high latency
    if (cpuUsage > 92 && networkLatencyMs > 12) {
      anomalies.push({
        id: `ANOM-LAT-${server.id}`,
        timestamp: '1m ago',
        deviceId: server.id,
        deviceName: `${server.name} (${server.rackId})`,
        deviceType: 'server',
        metric: 'CPU Utilization & Response Latency',
        currentValue: `${cpuUsage}% / ${networkLatencyMs}ms`,
        expectedRange: '30–75% / <4ms',
        anomalyScore: 0.92,
        severity: 'critical',
        possibleCause: 'Runaway thread contention or database lock cascade',
        recommendedAction: 'Profile thread dump via eBPF and prepare automated container autoscaling restart',
        status: 'active',
      });
    }
  });

  // Check cooling units
  cooling.forEach(unit => {
    if (unit.returnTempC - unit.supplyTempC > 10 || unit.copEfficiency < 2.5 || unit.status === 'critical') {
      anomalies.push({
        id: `ANOM-${unit.id}`,
        timestamp: 'Just now',
        deviceId: unit.id,
        deviceName: unit.name,
        deviceType: 'cooling',
        metric: 'Cooling COP & Return Air Heat Flux',
        currentValue: `COP ${unit.copEfficiency} / Return ${unit.returnTempC}°C`,
        expectedRange: 'COP 3.5–4.5 / Return <28°C',
        anomalyScore: 0.89,
        severity: unit.status === 'critical' ? 'critical' : 'warning',
        possibleCause: 'Compressor bypass or fan motor bearing degradation',
        recommendedAction: 'Check chilled water flow rate valve and verify belt tension',
        status: 'active',
      });
    }
  });

  // Check UPS units
  ups.forEach(u => {
    if (u.batteryHealthPercent < 70 || u.loadPercent > 85) {
      anomalies.push({
        id: `ANOM-${u.id}`,
        timestamp: '12m ago',
        deviceId: u.id,
        deviceName: u.name,
        deviceType: 'ups',
        metric: 'Battery State of Health (SOH) Degradation',
        currentValue: `${u.batteryHealthPercent}% Health / ${u.runtimeRemainingMinutes}min reserve`,
        expectedRange: '>85% Health / >30min reserve',
        anomalyScore: 0.84,
        severity: u.batteryHealthPercent < 50 ? 'critical' : 'warning',
        possibleCause: 'Increased internal cell resistance caused by prolonged high ambient temperature',
        recommendedAction: 'Initiate battery cell string discharge impedance diagnostic test',
        status: 'active',
      });
    }
  });

  return anomalies;
}

// Generate Time-Series Capacity Forecasts
export function generateCapacityForecast(timeHorizon: '7d' | '30d' | '90d' | '180d' | '365d'): CapacityForecastPoint[] {
  const points: CapacityForecastPoint[] = [];
  const daysCount = timeHorizon === '7d' ? 7 : timeHorizon === '30d' ? 30 : timeHorizon === '90d' ? 90 : timeHorizon === '180d' ? 180 : 365;
  const step = Math.max(1, Math.floor(daysCount / 14));

  const baseCpu = 64;
  const baseRam = 58;
  const baseStorage = 68;
  const basePower = 840;
  const powerLimit = 1100;
  const baseRacks = 72;
  const baseCooling = 61;
  const baseCost = 72500;

  const now = new Date();

  for (let i = 0; i <= daysCount; i += step) {
    const d = new Date(now.getTime() + i * 86400000);
    const dateLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    // Realistic exponential or linear growth curves with micro noise
    const progressRatio = i / 365;
    const cpuProjected = +(baseCpu + progressRatio * 28 + Math.sin(i * 0.2) * 1.5).toFixed(1);
    const ramProjected = +(baseRam + progressRatio * 24 + Math.sin(i * 0.15) * 1.2).toFixed(1);
    const storageProjected = +(baseStorage + progressRatio * 32 + (i * 0.04)).toFixed(1);
    const powerProjected = +(basePower + progressRatio * 260 + Math.sin(i * 0.1) * 12).toFixed(1);
    const rackOccupancy = +(baseRacks + progressRatio * 22).toFixed(1);
    const coolingProjected = +(baseCooling + progressRatio * 26).toFixed(1);
    const costProjected = Math.round(baseCost + progressRatio * 28000);

    points.push({
      date: dateLabel,
      cpuCapacityPercent: Math.min(100, cpuProjected),
      ramCapacityPercent: Math.min(100, ramProjected),
      storageCapacityPercent: Math.min(100, storageProjected),
      powerDemandKw: powerProjected,
      powerCapacityLimitKw: powerLimit,
      rackOccupancyPercent: Math.min(100, rackOccupancy),
      coolingCapacityPercent: Math.min(100, coolingProjected),
      projectedCost: costProjected,
    });
  }

  return points;
}

// What-If Simulation Math Engine
export function calculateWhatIfImpact(
  input: WhatIfScenarioInput,
  currentFacilityPowerKw: number,
  currentItPowerKw: number,
  currentPue: number
): WhatIfScenarioResult {
  const addedPowerKw = +((input.additionalServers * input.perServerPowerWatts) / 1000).toFixed(2);
  const newItPowerKw = currentItPowerKw + addedPowerKw;
  
  // Thermodynamic cooling penalty calculation (COP = 3.5 average)
  const addedCoolingKwRequired = +(addedPowerKw / (input.coolingEfficiencyFactor || 3.5)).toFixed(2);
  const newTotalPowerKw = +(currentFacilityPowerKw + addedPowerKw + addedCoolingKwRequired).toFixed(2);
  
  const projectedPUE = +(newTotalPowerKw / Math.max(1, newItPowerKw)).toFixed(3);
  const pueDelta = +(projectedPUE - currentPue).toFixed(3);

  // 1 standard rack accommodates ~20-25 servers with PDU and cable management
  const requiredRacks = Math.ceil(input.additionalServers / 22);
  const availableULeft = Math.max(0, 180 - input.additionalServers * 2);

  // Monthly electricity calculation: kW * 24h * 30.5d * rate
  const monthlyCostIncrease = Math.round((addedPowerKw + addedCoolingKwRequired) * 24 * 30.5 * input.electricityRate);

  const bottlenecks: string[] = [];
  const recommendations: string[] = [];

  if (newTotalPowerKw > 1050) {
    bottlenecks.push('Facility Main Substation Power Ceiling (1,100 kW limit)');
    recommendations.push('Provision secondary 500kVA transformer or implement active peak power capping.');
  }

  if (projectedPUE > 1.48) {
    bottlenecks.push('PUE Degradation beyond Energy Star / EU Green Data Center SLA (<1.45 target)');
    recommendations.push('Deploy hot-aisle containment curtains in Zone C before commissioning high-density racks.');
  }

  if (requiredRacks > 4) {
    bottlenecks.push('Available floor space & power distribution units (PDU) in Row-3');
    recommendations.push('Reallocate underutilized storage chassis in Row-1 to free up 3 contiguous rack bays.');
  }

  let capacityRiskLevel: WhatIfScenarioResult['capacityRiskLevel'] = 'Safe';
  if (newTotalPowerKw > 1020 || projectedPUE > 1.50) {
    capacityRiskLevel = 'Critical';
  } else if (newTotalPowerKw > 920 || projectedPUE > 1.44) {
    capacityRiskLevel = 'High';
  } else if (input.additionalServers > 30) {
    capacityRiskLevel = 'Moderate';
  }

  return {
    addedPowerKw,
    newTotalPowerKw,
    projectedPUE,
    pueDelta,
    addedCoolingKwRequired,
    requiredRacks,
    availableULeft,
    monthlyCostIncrease,
    capacityRiskLevel,
    bottlenecks,
    recommendations,
  };
}

// Causal Graph Root Cause Analysis
export function analyzeRootCause(
  anomalies: AnomalyRecord[],
  cooling: CoolingUnit[],
  racks: RackUnit[]
): {
  probableRootCause: string;
  confidence: number;
  incidentChain: string[];
  affectedRacks: string[];
  affectedServersCount: number;
  mitigationSteps: string[];
} {
  const degradedCooling = cooling.find(c => c.status === 'critical' || c.status === 'warning');
  const hotRacks = racks.filter(r => r.inletTempC > 27 || r.status === 'critical');

  if (degradedCooling && hotRacks.length > 0) {
    return {
      probableRootCause: `${degradedCooling.name} Fan Bearing & Airflow Velocity Degradation`,
      confidence: 93,
      incidentChain: [
        `${degradedCooling.id} actuator drift & fan motor harmonic vibration`,
        `Cold aisle static air pressure in Zone A drops by 34%`,
        `Racks ${hotRacks.map(r => r.id).join(', ')} experience hot exhaust air recirculation`,
        `Server CPU die temperatures elevate above 78°C`,
        `Automated thermal CPU throttling triggers latency spike across nodes`,
      ],
      affectedRacks: hotRacks.map(r => r.id),
      affectedServersCount: hotRacks.reduce((sum, r) => sum + r.servers.length, 0),
      mitigationSteps: [
        `Override CRAC-01 and CRAC-03 fan speeds to 85% to compensate zone static pressure`,
        `Migrate top 20% latency-sensitive workloads from Rack R-04 to Zone B`,
        `Dispatch HVAC emergency maintenance work order for ${degradedCooling.id}`,
      ],
    };
  }

  return {
    probableRootCause: 'Distributed Workload Surge with Localized High Density',
    confidence: 84,
    incidentChain: [
      'Batch AI training and database replication workload surge across compute clusters',
      'Average rack power consumption increased from 8.2 kW to 11.4 kW',
      'Localized delta T elevation across Zone A and Zone C',
    ],
    affectedRacks: ['R-02', 'R-07', 'R-09'],
    affectedServersCount: 28,
    mitigationSteps: [
      'Enable dynamic workload power capping via IPMI / Redfish API',
      'Increase chilled water supply flow rate by 15%',
    ],
  };
}

// Natural Language Telemetry Query Engine (Client-side fast search + grounding)
export function parseNaturalLanguageQuery(query: string, racks: RackUnit[], servers: ServerDevice[]) {
  const q = query.toLowerCase();

  if (q.includes('temperature') || q.includes('temp') || q.includes('hot') || q.includes('overheat')) {
    const hotRacks = racks.filter(r => r.inletTempC > 24).sort((a, b) => b.inletTempC - a.inletTempC);
    return {
      type: 'racks',
      title: 'Racks with Highest Inlet Temperatures',
      summary: `Found ${hotRacks.length} racks exceeding standard cold-aisle baseline (24°C).`,
      data: hotRacks.map(r => ({
        id: r.id,
        name: r.name,
        temp: `${r.inletTempC}°C Inlet / ${r.outletTempC}°C Outlet`,
        status: r.status,
        power: `${r.currentPowerKw} kW`,
      })),
    };
  }

  if (q.includes('cpu') || q.includes('utilization') || q.includes('load')) {
    const highCpuServers = servers.filter(s => s.telemetry.cpuUsage > 75).sort((a, b) => b.telemetry.cpuUsage - a.telemetry.cpuUsage);
    return {
      type: 'servers',
      title: 'Servers with High CPU Utilization (>75%)',
      summary: `Identified ${highCpuServers.length} compute nodes under heavy processing demand.`,
      data: highCpuServers.slice(0, 8).map(s => ({
        id: s.id,
        name: s.name,
        rack: s.rackId,
        cpu: `${s.telemetry.cpuUsage}%`,
        temp: `${s.telemetry.cpuTemp}°C`,
        status: s.status,
      })),
    };
  }

  if (q.includes('power') || q.includes('energy') || q.includes('kw') || q.includes('cost')) {
    const highPowerRacks = [...racks].sort((a, b) => b.currentPowerKw - a.currentPowerKw);
    return {
      type: 'racks',
      title: 'Top Power Consuming Racks',
      summary: `Top 5 racks account for ${highPowerRacks.slice(0, 5).reduce((s, r) => s + r.currentPowerKw, 0).toFixed(1)} kW of total load.`,
      data: highPowerRacks.slice(0, 5).map(r => ({
        id: r.id,
        name: r.name,
        power: `${r.currentPowerKw} kW (Max: ${r.maxPowerKw} kW)`,
        pduStatus: r.pduStatus,
        status: r.status,
      })),
    };
  }

  if (q.includes('fail') || q.includes('risk') || q.includes('maintenance')) {
    const atRisk = servers.filter(s => (s.failureProbability || 0) > 30 || s.status === 'critical');
    return {
      type: 'servers',
      title: 'Assets with Elevated Failure Risk',
      summary: `${atRisk.length} assets require preventive inspection or component replacement.`,
      data: atRisk.map(s => ({
        id: s.id,
        name: s.name,
        rack: s.rackId,
        risk: `${s.failureProbability || 45}% failure probability`,
        status: s.status,
      })),
    };
  }

  return {
    type: 'general',
    title: 'Data Center Operational Search',
    summary: `Search results matching "${query}" across fleet telemetry.`,
    data: racks.slice(0, 4).map(r => ({
      id: r.id,
      name: r.name,
      health: `${r.healthScore}/100`,
      status: r.status,
      power: `${r.currentPowerKw} kW`,
    })),
  };
}
